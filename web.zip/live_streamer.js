// DA.AI Live Voice v2.2 (tools: app control, Google Search, Android actions) — real two-way voice conversation over the Gemini Live API
// Listens and speaks at the same time, waits for you to finish, stops the moment you talk over it.
// Audio in: 16 kHz PCM16 (realtimeInput.audio) · Audio out: 24 kHz PCM16 · Server-side voice activity detection.
(function () {
  "use strict";
  const WS_BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=";
  const MODELS = ["gemini-3.8-live", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-preview-09-2025"];
  const VOICES = { female: "Aoede", male: "Charon" };

  // AudioWorklet: collects mic samples and posts ~40 ms frames to the main thread
  const WORKLET = `
    class DaMic extends AudioWorkletProcessor {
      constructor(){ super(); this.buf = []; this.n = 0; this.size = Math.round(sampleRate * 0.04); }
      process(inputs){
        const ch = inputs[0] && inputs[0][0];
        if (ch) { this.buf.push(new Float32Array(ch)); this.n += ch.length;
          if (this.n >= this.size) { const out = new Float32Array(this.n); let o = 0;
            for (const b of this.buf) { out.set(b, o); o += b.length; }
            this.port.postMessage(out, [out.buffer]); this.buf = []; this.n = 0; } }
        return true;
      }
    }
    registerProcessor("da-mic", DaMic);`;

  class GeminiLiveAudioStreamer {
    constructor(opts) {
      opts = opts || {};
      this.apiKey = opts.apiKey || (typeof gemKey === "function" ? gemKey() : "");
      this.fallbackKey = opts.fallbackKey || "";
      this.voice = opts.voice || "female";
      this.agentName = opts.agentName || "DA.AI";
      this.userName = opts.userName || "";
      this.userGender = opts.userGender || ""; this.warmth = opts.warmth || ""; // v2.43
      this.extraInstruction = opts.extraInstruction || "";
      this.onStateChange = opts.onStateChange || function () {};
      this.onUserText = opts.onUserText || function () {};
      this.onBotText = opts.onBotText || function () {};
      this.onTurnComplete = opts.onTurnComplete || function () {};
      this.onLevel = opts.onLevel || function () {};
      this.onError = opts.onError || function () {};
      this.tools = opts.tools || [];                       // [{name, description, parameters}]
      this.onToolCall = opts.onToolCall || null;           // async (name, args) => result
      this.onToolActivity = opts.onToolActivity || function () {};
      this.instruction = opts.instruction || "";
      this.ws = null; this.ctx = null; this.stream = null; this.node = null; this.src = null;
      this.sources = []; this.playAt = 0; this.ready = false; this.closed = false; this.muted = false;
      this.modelIdx = 0; this.resumeHandle = null; this.reconnects = 0;
      this.userText = ""; this.botText = ""; this.state = "idle";
    }

    _state(s, t) { if (this.state !== s || t) { this.state = s; this.onStateChange(s, t); } }

    async start() {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("הדפדפן לא תומך בשיחה קולית");
      if (!this.apiKey) throw new Error("חסר מפתח Gemini");
      this.loud = GeminiLiveAudioStreamer.loud();
      try {
        const A = window.AndroidApp;
        if (A && this.loud && A.voiceModeLoud) A.voiceModeLoud(true); else if (A && A.voiceMode) A.voiceMode(true);
      } catch (e) {}
      this.ctx = new AC({ latencyHint: "interactive" });
      if (this.ctx.state === "suspended") await this.ctx.resume();
      this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 256;
      // v2.10.1: louder voice — digital boost + limiter (phones play call audio quietly)
      this.outGain = this.ctx.createGain(); this.outGain.gain.value = GeminiLiveAudioStreamer.boost();
      this.limiter = this.ctx.createDynamicsCompressor();
      try { this.limiter.threshold.value = -10; this.limiter.knee.value = 6; this.limiter.ratio.value = 14; this.limiter.attack.value = 0.002; this.limiter.release.value = 0.2; } catch (e) {}
      this.outGain.connect(this.limiter); this.limiter.connect(this.analyser); this.analyser.connect(this.ctx.destination);
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      });
      await this._startMic();
      this._levelLoop();
      // v2.17: through the DA.ai server — the WebSocket carries the user's sign-in token, not an API key
      if (this.apiKey === "server" || this.fallbackKey === "server") {
        try { this.serverToken = await DACloud.freshToken(); } catch (e) { if (this.apiKey === "server") throw new Error("כדי לדבר עם הסוכן צריך להתחבר עם Google"); }
      }
      await this._connect();
    }

    async _startMic() {
      this.src = this.ctx.createMediaStreamSource(this.stream);
      const onFrame = (f32) => this._sendAudio(f32);
      try {
        const url = URL.createObjectURL(new Blob([WORKLET], { type: "application/javascript" }));
        await this.ctx.audioWorklet.addModule(url);
        this.node = new AudioWorkletNode(this.ctx, "da-mic");
        this.node.port.onmessage = (e) => onFrame(e.data);
      } catch (e) { // older WebView
        this.node = this.ctx.createScriptProcessor(2048, 1, 1);
        this.node.onaudioprocess = (ev) => onFrame(new Float32Array(ev.inputBuffer.getChannelData(0)));
      }
      const mute = this.ctx.createGain(); mute.gain.value = 0;
      this.src.connect(this.node); this.node.connect(mute); mute.connect(this.ctx.destination);
    }

    _connect() {
      return new Promise((resolve, reject) => {
        let settled = false;
        const key = this.reconnects > 2 && this.fallbackKey ? this.fallbackKey : this.apiKey;
        const url = key === "server"
          ? DAServer.url().replace(/^http/, "ws") + "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?token=" + encodeURIComponent(this.serverToken || "")
          : WS_BASE + encodeURIComponent(key);
        const ws = new WebSocket(url);
        this.ws = ws; this.ready = false;
        this._state("connecting", "מתחבר…");
        const failSetup = (why) => {
          if (settled) return; settled = true;
          if (this.modelIdx < MODELS.length - 1) { this.modelIdx++; this._connect().then(resolve, reject); }
          else if (key !== this.fallbackKey && this.fallbackKey) { this.reconnects = 3; this.modelIdx = 0; this._connect().then(resolve, reject); }
          else { const e = new Error(why || "החיבור לשיחה הקולית נכשל"); if (/quota|exceeded|billing/i.test(why || "")) e.code = "quota"; reject(e); }
        };
        const timer = setTimeout(() => { try { ws.close(); } catch (e) {} failSetup("השרת לא ענה"); }, 15000);
        ws.onopen = () => ws.send(JSON.stringify({ setup: this._setupMsg() }));
        ws.onmessage = async (ev) => {
          if (ws !== this.ws) return;
          let m; try { m = JSON.parse(typeof ev.data === "string" ? ev.data : await ev.data.text()); } catch (e) { return; }
          if (m.setupComplete) { clearTimeout(timer); settled = true; this.ready = true; this.reconnects = 0; this._state("listening", "מקשיב…"); resolve(); return; }
          this._onMessage(m);
        };
        ws.onerror = () => { if (ws === this.ws && !this.ready) { clearTimeout(timer); failSetup(); } };
        ws.onclose = (ev) => {
          clearTimeout(timer);
          if (ws !== this.ws) return; // an older socket we already replaced
          if (!this.ready && !settled) { failSetup(ev.reason ? String(ev.reason).slice(0, 120) : ""); return; }
          this.ready = false;
          if (this.closed) return;
          const why = String(ev.reason || "");
          if (/quota|billing|exceeded|permission|api key/i.test(why)) {
            const err = new Error(/quota|exceeded|billing/i.test(why) ? "נגמרה המכסה החינמית של השיחה החיה למפתח הזה" : "המפתח לא מורשה לשיחה החיה");
            err.code = /quota|exceeded|billing/i.test(why) ? "quota" : "bad_key"; this.onError(err); return;
          }
          // session ended (time limit / network) → reconnect and resume the same conversation
          if (this.reconnects++ < 5) { this._state("connecting", "מתחבר מחדש…"); setTimeout(() => this._connect().catch((e) => this.onError(e)), 600); }
          else this.onError(new Error("השיחה נותקה"));
        };
      });
    }

    _setupMsg() {
      const s = {
        model: "models/" + MODELS[this.modelIdx],
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: VOICES[this.voice] || VOICES.female } } }
        },
        systemInstruction: { parts: [{ text:
          "אתה " + this.agentName + ", עוזר קולי של DA.ai בשיחת טלפון חיה עם " + (this.userName || "המשתמש") + ". דבר עברית מדוברת, חמה וטבעית, כמו בן אדם. " +
          (this.userGender === "f" ? "את מדבר עם אישה — פנה אליה בלשון נקבה. " : this.userGender === "m" ? "אתה מדבר עם גבר — פנה אליו בלשון זכר. " : "") + (this.warmth ? this.warmth + " " : "") +
          "ענה קצר: משפט או שניים, אלא אם ביקשו פירוט. שאל שאלת המשך כשמתאים. " +
          "התמקד בדיוק במה שנשאל, וענה קודם על השאלה עצמה. אם לא שמעת טוב או שהבקשה לא ברורה, בקש בקצרה לחזור במקום לנחש. " +
          "על מזג אוויר, חדשות, מחירים וכל מידע עדכני, השתמש בכלים (weather, web_search) ואל תמציא. דבר בקצב רגוע ובהגייה ברורה. " +
          "המשתמש לפעמים עוצר לחשוב באמצע משפט — חכה שיסיים. אם הוא מתחיל לדבר בזמן שאתה מדבר, עצור והקשב. " +
          "בלי רשימות, בלי markdown, בלי לקרוא סימנים. " + (this.voice === "male" ? "הקול שלך גברי: דבר על עצמך בלשון זכר (אני יכול, אני שמח). " : "הקול שלך נשי: דברי על עצמך בלשון נקבה (אני יכולה, אני שמחה). ") + this.extraInstruction + "\n\n" + this.instruction }] },
        realtimeInputConfig: { automaticActivityDetection: {
          startOfSpeechSensitivity: "START_SENSITIVITY_HIGH",  // hear the user even while the model is talking
          endOfSpeechSensitivity: "END_SENSITIVITY_LOW",       // don't cut the user off on short pauses
          prefixPaddingMs: 200,
          silenceDurationMs: 1000
        } },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        sessionResumption: this.resumeHandle ? { handle: this.resumeHandle } : {},
        contextWindowCompression: { slidingWindow: {} } // long calls + screen sharing without hitting the session limit
      };
      // v2.9.2: no built-in googleSearch here — its free quota kills the whole live call (error 1011).
      // Web/weather go through our own function tools instead.
      if (this.tools.length && this.onToolCall) s.tools = [{ functionDeclarations: this.tools }];
      return s;
    }

    _onMessage(m) {
      if (m.sessionResumptionUpdate && m.sessionResumptionUpdate.resumable && m.sessionResumptionUpdate.newHandle) this.resumeHandle = m.sessionResumptionUpdate.newHandle;
      if (m.goAway) { try { this.ws.close(); } catch (e) {} return; } // onclose reconnects with the handle
      if (m.toolCall && m.toolCall.functionCalls) { this._runTools(m.toolCall.functionCalls); return; }
      const sc = m.serverContent; if (!sc) return;
      if (sc.inputTranscription && sc.inputTranscription.text) {
        this.userText += sc.inputTranscription.text; this.onUserText(this.userText.trim());
        if (this.state !== "speaking") this._state("listening", "מקשיב…");
      }
      if (sc.interrupted) { this.stopPlayback(); if (!this.muted) this._state("listening", "מקשיב…"); }
      if (sc.modelTurn && sc.modelTurn.parts) {
        for (const p of sc.modelTurn.parts) {
          const d = p.inlineData || p.inline_data;
          if (d && d.data) { this._play(d.data); this._state("speaking", "מדבר…"); }
        }
      }
      if (sc.outputTranscription && sc.outputTranscription.text) { this.botText += sc.outputTranscription.text; this.onBotText(this.botText.trim()); }
      if (sc.turnComplete) {
        const u = this.userText.trim(), b = this.botText.trim();
        this.userText = ""; this.botText = "";
        if (u || b) this.onTurnComplete(u, b);
        const left = Math.max(0, (this.playAt - this.ctx.currentTime) * 1000);
        clearTimeout(this._idleT); this._idleT = setTimeout(() => { if (!this.sources.length && !this.muted) this._state("listening", "מקשיב…"); }, left + 120);
      }
    }

    async _runTools(calls) {
      const responses = [];
      for (const fc of calls) {
        let result;
        this.onToolActivity(fc.name, fc.args || {});
        try {
          const r = await Promise.race([
            Promise.resolve(this.onToolCall(fc.name, fc.args || {})),
            new Promise((_, bad) => setTimeout(() => bad(new Error("timeout")), 45000))
          ]);
          result = (r === undefined || r === null) ? { ok: true } : Array.isArray(r) ? { result: r } : (typeof r === "object" ? r : { result: String(r) });
        } catch (e) { result = { error: String(e && e.message || e).slice(0, 300) }; }
        const json = JSON.stringify(result);
        if (json.length > 12000) result = { result: json.slice(0, 12000) };
        responses.push({ id: fc.id, name: fc.name, response: result });
      }
      if (this.ready && this.ws && this.ws.readyState === 1) {
        try { this.ws.send(JSON.stringify({ toolResponse: { functionResponses: responses } })); } catch (e) {}
      }
    }

    // instant local barge-in: if the user starts talking while the model speaks, go quiet right away
    _bargeIn(f32) {
      let sum = 0; for (let i = 0; i < f32.length; i += 2) sum += f32[i] * f32[i];
      const rms = Math.sqrt(sum / (f32.length / 2));
      if (this.state !== "speaking") { this._loud = 0; this._floor = 0; return; }
      // learn the leftover echo level during the first moments of speech, then look for a clear jump
      this._floor = this._floor ? (rms < this._floor ? rms : this._floor * 0.995 + rms * 0.005) : rms;
      const thr = this.loud ? Math.max(0.05, this._floor * 2.4) : Math.max(0.03, this._floor * 3.2);
      this._loud = rms > thr ? (this._loud || 0) + f32.length / this.ctx.sampleRate : Math.max(0, (this._loud || 0) - 0.02);
      if (this._loud > 0.22) { this._loud = 0; this.stopPlayback(); this._state("listening", "מקשיב…"); }
    }

    _sendAudio(f32) {
      if (!this.muted) try { this._bargeIn(f32); } catch (e) {}
      if (!this.ready || this.muted || !this.ws || this.ws.readyState !== 1) return;
      // loud speaker mode: while the AI talks, don't stream its own echo back to it (local barge-in still listens)
      if (this.loud && this.state === "speaking") f32 = new Float32Array(f32.length);
      const pcm = GeminiLiveAudioStreamer.toPcm16(f32, this.ctx.sampleRate, 16000);
      try { this.ws.send(JSON.stringify({ realtimeInput: { audio: { data: GeminiLiveAudioStreamer.b64(pcm), mimeType: "audio/pcm;rate=16000" } } })); } catch (e) {}
    }

    static loud() { try { return localStorage.getItem("daai_voice_loud") !== "0"; } catch (e) { return true; } }
    static boost() { try { const v = parseFloat(localStorage.getItem("daai_voice_boost")); return v >= 1 && v <= 5 ? v : 3; } catch (e) { return 3; } }
    setBoost(v) { v = Math.max(1, Math.min(5, Number(v) || 3)); try { localStorage.setItem("daai_voice_boost", String(v)); } catch (e) {} if (this.outGain) this.outGain.gain.value = v; }

    sendText(text) {
      if (this.ready && text) try { this.ws.send(JSON.stringify({ realtimeInput: { text: String(text) } })); } catch (e) {}
    }
    sendImage(base64Jpeg, question) {
      if (!this.ready) return;
      try { this.ws.send(JSON.stringify({ realtimeInput: { video: { data: base64Jpeg, mimeType: "image/jpeg" } } })); } catch (e) {}
      if (question) this.sendText(question);
    }

    _play(b64) {
      const bin = atob(b64), n = bin.length >> 1, buf = this.ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
      for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
      const s = this.ctx.createBufferSource(); s.buffer = buf; s.connect(this.outGain);
      const now = this.ctx.currentTime; if (this.playAt < now + 0.03) this.playAt = now + 0.06;
      s.start(this.playAt); this.playAt += buf.duration;
      this.sources.push(s);
      s.onended = () => { this.sources = this.sources.filter((x) => x !== s); if (!this.sources.length && this.state === "speaking") this._state(this.muted ? "idle" : "listening", this.muted ? "מיקרופון מושתק" : "מקשיב…"); };
    }

    stopPlayback() {
      for (const s of this.sources) { try { s.stop(); } catch (e) {} }
      this.sources = []; if (this.ctx) this.playAt = this.ctx.currentTime;
    }

    setMuted(m) {
      this.muted = !!m;
      if (this.muted && this.ready) try { this.ws.send(JSON.stringify({ realtimeInput: { audioStreamEnd: true } })); } catch (e) {}
      this._state(this.muted ? "idle" : "listening", this.muted ? "מיקרופון מושתק" : "מקשיב…");
    }

    _levelLoop() {
      const data = new Uint8Array(this.analyser.frequencyBinCount);
      const tick = () => {
        if (this.closed) return;
        this.analyser.getByteTimeDomainData(data);
        let sum = 0; for (let i = 0; i < data.length; i++) { const v = (data[i] - 128) / 128; sum += v * v; }
        this.onLevel(Math.min(1, Math.sqrt(sum / data.length) * 4));
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }

    stop() {
      this.closed = true; this.ready = false;
      try { this.ws && this.ws.close(); } catch (e) {}
      this.stopPlayback();
      try { this.src && this.src.disconnect(); this.node && this.node.disconnect(); } catch (e) {}
      try { this.stream && this.stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
      try { this.ctx && this.ctx.close(); } catch (e) {}
      try { const A = window.AndroidApp; if (A && A.voiceModeLoud) A.voiceModeLoud(false); if (A && A.voiceMode) A.voiceMode(false); } catch (e) {}
      this._state("idle", "מוכן");
    }

    static toPcm16(f32, inRate, outRate) {
      let s = f32;
      if (inRate !== outRate) {
        const ratio = inRate / outRate, len = Math.floor(f32.length / ratio); s = new Float32Array(len);
        for (let i = 0; i < len; i++) { // average = simple anti-alias low-pass
          const a = Math.floor(i * ratio), b = Math.min(f32.length, Math.floor((i + 1) * ratio)); let acc = 0;
          for (let j = a; j < b; j++) acc += f32[j]; s[i] = b > a ? acc / (b - a) : f32[a] || 0;
        }
      }
      const out = new Int16Array(s.length);
      for (let i = 0; i < s.length; i++) { const v = Math.max(-1, Math.min(1, s[i])); out[i] = v < 0 ? v * 0x8000 : v * 0x7fff; }
      return out.buffer;
    }
    static b64(buf) {
      const bytes = new Uint8Array(buf); let bin = "";
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      return btoa(bin);
    }
  }
  window.GeminiLiveAudioStreamer = GeminiLiveAudioStreamer;
})();
