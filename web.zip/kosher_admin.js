/* DA.ai כשר — the owner's panel (only for David): phones, app requests, approve / refuse / release.
   Opens from the owner hub button. Talks to the server routes /k/admin/* (owner + owner password). */
(function () {
  "use strict";
  var esc = function (t) { return String(t == null ? "" : t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var box = null, data = [];

  async function api(path, body) {
    if (!(window.DAServer && DAServer.call)) throw new Error("השרת לא מחובר");
    var r = await DAServer.call(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    var j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw new Error((j.error && j.error.message) || ("שגיאה " + r.status));
    return j;
  }
  function when(ms) {
    if (!ms) return "אף פעם";
    var m = Math.round((Date.now() - ms) / 60000);
    if (m < 2) return "עכשיו"; if (m < 60) return "לפני " + m + " דק׳";
    var h = Math.round(m / 60); if (h < 24) return "לפני " + h + " שע׳";
    return new Date(ms).toLocaleDateString("he-IL");
  }
  function until(t) { return t ? "עד " + new Date(t).toLocaleString("he-IL", { dateStyle: "short", timeStyle: "short" }) : "קבוע"; }

  function frame() {
    if (box) return box;
    box = document.createElement("div");
    box.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(5,6,12,.96);overflow:auto;direction:rtl;color:#fff;font-family:inherit;padding:14px 12px 40px";
    document.body.appendChild(box);
    return box;
  }
  function close() { if (box) { box.remove(); box = null; } }

  function render(msg) {
    var b = frame();
    var reqCount = data.reduce(function (n, d) { return n + Object.keys(d.req || {}).length; }, 0);
    var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">' +
      '<b style="font-size:18px;color:#f0d488">🛡️ DA.ai כשר — ניהול</b>' +
      '<button data-a="close" style="background:none;border:0;color:#fff;font-size:24px">✕</button></div>' +
      '<div style="font-size:13px;opacity:.8;margin-bottom:8px">' + data.length + ' טלפונים · ' + reqCount + ' בקשות ממתינות</div>' +
      '<button data-a="reload" style="width:100%;padding:10px;border-radius:10px;border:1px solid #f0d48866;background:#f0d48822;color:#f0d488;font-weight:700;margin-bottom:10px">🔄 רענן</button>' +
      (msg ? '<div style="background:#ff6b6b22;color:#ff9b9b;padding:8px;border-radius:8px;margin-bottom:8px">' + esc(msg) + '</div>' : '');
    if (!data.length) h += '<div style="opacity:.8;line-height:1.6;padding:10px">עוד אין טלפונים. מתקינים את <b>DA.ai כשר</b> בטלפון, כותבים שם — והטלפון יופיע כאן.</div>';
    data.forEach(function (d) {
      var req = Object.keys(d.req || {}), ap = Object.keys(d.approved || {});
      h += '<div style="border:1px solid #2c2838;background:#17151e;border-radius:14px;padding:12px;margin-bottom:10px">' +
        '<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font-size:16px">📱 ' + esc(d.name) + '</b>' +
        '<div style="font-size:12px;opacity:.7">' + esc(d.model || "") + ' · נראה ' + when(d.seen) + '</div></div>' +
        (d.released ? '<span style="font-size:12px;background:#5fd38d22;color:#5fd38d;padding:3px 8px;border-radius:99px">🔓 משוחרר</span>' : '<span style="font-size:12px;background:#f0d48822;color:#f0d488;padding:3px 8px;border-radius:99px">🛡️ מוגן</span>') + '</div>';
      if (req.length) {
        h += '<div style="margin-top:10px;font-weight:700;color:#f0d488">🙋 בקשות (' + req.length + ')</div>';
        req.forEach(function (p) {
          var l = d.req[p].l || (d.labels || {})[p] || p;
          h += '<div style="padding:8px 0;border-bottom:1px solid #2c2838"><div><b>' + esc(l) + '</b> <span style="font-size:11px;opacity:.6;direction:ltr">' + esc(p) + '</span></div>' +
            '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">' +
            btn("✅ אשר", "approve", d.id, p, 0, "#5fd38d") + btn("⏳ שעתיים", "approve", d.id, p, 2, "#f0d488") +
            btn("⏳ יום", "approve", d.id, p, 24, "#f0d488") + btn("✖ דחה", "deny", d.id, p, 0, "#ff8b8b") + '</div></div>';
        });
      }
      if (ap.length) {
        h += '<details style="margin-top:10px"><summary style="cursor:pointer;opacity:.85">✓ מאושרות (' + ap.length + ')</summary>';
        ap.forEach(function (p) {
          h += '<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #2c2838"><span>' + esc((d.labels || {})[p] || p) +
            ' <span style="font-size:11px;opacity:.6">' + until(d.approved[p]) + '</span></span>' + btn("בטל", "revoke", d.id, p, 0, "#ff8b8b") + '</div>';
        });
        h += '</details>';
      }
      h += '<div style="display:flex;gap:6px;margin-top:10px">' +
        '<button data-a="release" data-id="' + d.id + '" data-on="' + (d.released ? "0" : "1") + '" style="flex:1;padding:9px;border-radius:9px;border:1px solid #444;background:#1f1c28;color:#fff">' + (d.released ? "🔒 נעל שוב" : "🔓 שחרר טלפון") + '</button>' +
        '<button data-a="delete" data-id="' + d.id + '" style="padding:9px 12px;border-radius:9px;border:1px solid #444;background:#1f1c28;color:#ff8b8b">🗑️</button></div></div>';
    });
    b.innerHTML = h;
    b.querySelectorAll("button[data-a]").forEach(function (x) { x.onclick = function () { act(x); }; });
  }
  function btn(t, op, id, p, hours, color) {
    return '<button data-a="set" data-op="' + op + '" data-id="' + id + '" data-p="' + esc(p) + '" data-h="' + hours + '" style="padding:7px 10px;border-radius:8px;border:1px solid ' + color + '66;background:' + color + '1a;color:' + color + ';font-weight:600;font-size:13px">' + t + '</button>';
  }

  async function act(x) {
    var a = x.dataset.a;
    if (a === "close") return close();
    try {
      if (a === "set") { x.disabled = true; await api("/k/admin/set", { id: x.dataset.id, pkg: x.dataset.p, op: x.dataset.op, hours: Number(x.dataset.h) || 0 }); }
      if (a === "release") {
        var on = x.dataset.on === "1";
        if (on && !confirm("לשחרר את הטלפון? כל האפליקציות ייפתחו, ויהיה אפשר להסיר את DA.ai כשר.")) return;
        await api("/k/admin/release", { id: x.dataset.id, on: on });
      }
      if (a === "delete") {
        if (!confirm("למחוק את הטלפון מהרשימה? (אם האפליקציה עדיין מותקנת בו — הוא יישאר חסום עד שישוחרר)")) return;
        await api("/k/admin/delete", { id: x.dataset.id });
      }
      await load();
    } catch (e) { render(e.message || String(e)); }
  }

  async function load() {
    try { data = (await api("/k/admin/list")).devices || []; render(); }
    catch (e) { data = data || []; render(e.message || String(e)); }
  }

  window.daKosherAdmin = function () {
    if (!(window.isVerifiedOwner && window.isVerifiedOwner())) { alert("רק לבעלים"); return; }
    data = []; frame().innerHTML = '<div style="padding:40px;text-align:center;color:#f0d488">טוען…</div>';
    load();
  };
})();
