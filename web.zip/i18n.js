/* v2.47: DA.ai in six languages.
   The app is written in Hebrew. For another language, every Hebrew text on the app's own screens
   (buttons, menus, settings, windows, toasts) is swapped for its translation. Translations come from
   the DA.ai server, which translates each text once and keeps it for everyone, and are cached on the phone.
   Chat messages, what the user types and the user's own data are never touched. */
(function () {
  var LANGS = { en: "English", he: "עברית", fr: "Français", ru: "Русский", am: "አማርኛ", ar: "العربية" };
  var SPEECH = { he: "he-IL", en: "en-US", fr: "fr-FR", ru: "ru-RU", am: "am-ET", ar: "ar-IL" };
  var L = "he";
  try { L = localStorage.getItem("daai_lang") || "he"; } catch (e) {}
  if (!LANGS[L]) L = "he";
  var RTL = L === "he" || L === "ar";
  document.documentElement.lang = L;
  document.documentElement.dir = RTL ? "rtl" : "ltr";
  if (!RTL) document.documentElement.classList.add("daLtr");

  window.DALang = {
    list: LANGS, get: function () { return L; },
    set: function (l) { if (!LANGS[l]) return; try { localStorage.setItem("daai_lang", l); } catch (e) {} location.reload(); },
    name: function () { return ({ he: "Hebrew", en: "English", fr: "French", ru: "Russian", am: "Amharic", ar: "Arabic" })[L]; }
  };
  window.daSL = function () { return SPEECH[L] || "he-IL"; };
  if (L === "he") return;

  var KEY = "daai_tr_" + L, cache = {};
  try { cache = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) {}
  var HEB = /[֐-׿]/;
  var SKIP = "#msgs, .bub, textarea, input, select option.noTr, [contenteditable], script, style, .noTr, #daTrBox, .vn-transcript, #famList, #mpList, .sName";
  var pending = {}, nPending = 0, applying = false;

  function tr(s) {
    var k = s.trim(); if (!k || !HEB.test(k)) return null;
    if (cache[k] != null) return s.replace(k, cache[k]);
    if (!pending[k] && k.length <= 400) { pending[k] = 1; nPending++; }
    return null;
  }
  function skip(el) { try { return !el || !!el.closest(SKIP); } catch (e) { return true; } }
  function doText(n) {
    var orig = n.__daHe != null && n.nodeValue === n.__daTr ? n.__daHe : n.nodeValue;
    if (!orig || !HEB.test(orig) || skip(n.parentElement)) return;
    var t = tr(orig); n.__daHe = orig;
    if (t != null && n.nodeValue !== t) { n.nodeValue = t; n.__daTr = t; }
  }
  var ATTRS = ["placeholder", "aria-label", "title"];
  function doEl(el) {
    if (skip(el.parentElement || el) && el.tagName !== "INPUT" && el.tagName !== "TEXTAREA") return;
    if ((el.tagName === "INPUT" || el.tagName === "TEXTAREA") && el.closest(".noTr")) return;
    ATTRS.forEach(function (a) {
      var v = el.getAttribute(a); if (!v || !HEB.test(v)) return;
      el.__daA = el.__daA || {}; if (el.__daA[a + "_t"] !== v) el.__daA[a] = v;
      var t = tr(el.__daA[a]); if (t != null && v !== t) { el.setAttribute(a, t); el.__daA[a + "_t"] = t; }
    });
  }
  function walk(root) {
    if (!root || root.nodeType === 3) { if (root) doText(root); return; }
    if (root.nodeType !== 1 || skip(root) && root !== document.body) return;
    applying = true;
    try {
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), n;
      while ((n = w.nextNode())) doText(n);
      if (root.matches && root.matches("[placeholder],[aria-label],[title]")) doEl(root);
      root.querySelectorAll && root.querySelectorAll("[placeholder],[aria-label],[title]").forEach(doEl);
      if (root === document.body || root === document.documentElement) { var t = tr(document.title); if (t) document.title = t; }
    } catch (e) {}
    applying = false;
    if (nPending) soon();
  }
  var roots = [], rt = 0;
  function queue(n) { roots.push(n); if (!rt) rt = setTimeout(function () { rt = 0; var r = roots; roots = []; r.forEach(walk); }, 30); }

  var ft = 0, busy = false;
  function soon() { if (!ft) ft = setTimeout(flush, 700); }
  async function flush() {
    ft = 0; if (busy || !nPending) return;
    if (!(window.DAServer && DAServer.url && DAServer.url())) { ft = setTimeout(flush, 3000); return; }
    busy = true;
    var list = Object.keys(pending).slice(0, 150);
    try {
      var r = await DAServer.call("/i18n", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lang: L, strings: list }) });
      if (r.ok) {
        var j = await r.json(), got = j.t || {};
        list.forEach(function (k) { delete pending[k]; nPending--; if (got[k] != null) cache[k] = got[k]; });
        try { localStorage.setItem(KEY, JSON.stringify(cache)); } catch (e) {}
        walk(document.body);
      } else { busy = false; ft = setTimeout(flush, 8000); return; }
    } catch (e) { busy = false; ft = setTimeout(flush, 8000); return; }
    busy = false;
    if (nPending) soon();
  }

  function start() {
    walk(document.body);
    new MutationObserver(function (ms) {
      if (applying) return;
      ms.forEach(function (m) {
        if (m.type === "characterData") queue(m.target);
        else if (m.type === "attributes") { if (m.target.nodeType === 1) queue(m.target); }
        else m.addedNodes.forEach(queue);
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
