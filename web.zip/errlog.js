/* v2.53: when something breaks on a user's phone, David hears about it — without anyone having to tell him.
   Only what broke (error text, where, app version, phone model) is sent; never messages or personal data. */
(function () {
  var Q = "daai_errq", seen = {};
  var ver = (/[?&]v=([^&]+)/.exec(location.search) || [])[1] || "";
  var dev = ((/Android [\d.]+; ([^;)]+)/.exec(navigator.userAgent) || [])[1] || "").trim();
  function q() { try { return JSON.parse(localStorage.getItem(Q) || "[]"); } catch (e) { return []; } }
  function add(msg, where) {
    msg = String(msg || "").replace(/\s+/g, " ").slice(0, 300); if (!msg || /ResizeObserver|Script error\.?$/.test(msg)) return;
    if (seen[msg]) return; seen[msg] = 1;
    var l = q(); l.push({ t: Date.now(), msg: msg, where: String(where || "").slice(0, 120), ver: ver, dev: dev, lang: (localStorage.getItem("daai_lang") || "he") });
    try { localStorage.setItem(Q, JSON.stringify(l.slice(-20))); } catch (e) {}
  }
  window.addEventListener("error", function (e) { add(e.message, (e.filename || "").split("/").pop() + ":" + e.lineno); });
  window.addEventListener("unhandledrejection", function (e) { var r = e.reason; add("Promise: " + (r && r.message ? r.message : r), r && r.stack ? String(r.stack).split("\n")[1] : ""); });
  window.daReportError = add;
  var busy = false;
  async function flush() {
    if (busy) return; var l = q(); if (!l.length) return;
    if (!(window.DAServer && DAServer.url && DAServer.url())) return;
    busy = true;
    try { var r = await DAServer.call("/errlog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: l }) }); if (r.ok) localStorage.setItem(Q, "[]"); } catch (e) {}
    busy = false;
  }
  window.addEventListener("load", function () {
    // a crash of the Android part last time
    try { var c = window.AndroidApp && AndroidApp.takeCrash ? AndroidApp.takeCrash() : ""; if (c) add("Android crash: " + c.split("\n")[0], c.split("\n").slice(1, 3).join(" ")); } catch (e) {}
    setTimeout(flush, 15000); setInterval(flush, 120000);
  });
})();
