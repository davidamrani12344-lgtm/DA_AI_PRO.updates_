/* DA.ai v2.36 — import your conversations from Claude, ChatGPT and Gemini (from their official "export my data" files),
   keep them on this phone (IndexedDB), and let the agents search them with the past_chats tool. */
(function () {
  "use strict";
  var DBN = "daai_kb", ST = "convs";

  function db() {
    return new Promise(function (res, rej) {
      var r = indexedDB.open(DBN, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(ST, { keyPath: "id" }); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }
  function tx(mode, fn) {
    return db().then(function (d) {
      return new Promise(function (res, rej) {
        var t = d.transaction(ST, mode), s = t.objectStore(ST), out = fn(s);
        t.oncomplete = function () { res(out && out.result !== undefined ? out.result : out); };
        t.onerror = function () { rej(t.error); };
      });
    });
  }
  function allConvs() {
    return db().then(function (d) {
      return new Promise(function (res, rej) {
        var r = d.transaction(ST, "readonly").objectStore(ST).getAll();
        r.onsuccess = function () { res(r.result || []); }; r.onerror = function () { rej(r.error); };
      });
    });
  }

  /* ---------- a small ZIP reader (the export files are .zip) ---------- */
  async function unzip(buf, want) {
    var dv = new DataView(buf), u8 = new Uint8Array(buf), end = -1;
    for (var i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { end = i; break; }
    if (end < 0) throw new Error("זה לא קובץ ZIP תקין");
    var n = dv.getUint16(end + 10, true), p = dv.getUint32(end + 16, true), out = {}, dec = new TextDecoder();
    for (var k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      var method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true),
        xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
      var name = dec.decode(u8.subarray(p + 46, p + 46 + nl));
      p += 46 + nl + xl + cl;
      if (!want(name)) continue;
      var lnl = dv.getUint16(off + 26, true), lxl = dv.getUint16(off + 28, true), start = off + 30 + lnl + lxl;
      var data = u8.subarray(start, start + csize);
      if (method === 8) {
        var ds = new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw")));
        out[name] = await ds.text();
      } else if (method === 0) out[name] = dec.decode(data);
    }
    return out;
  }

  /* ---------- turn each service's format into { src, title, date, msgs: [{ r: "u"|"a", t }] } ---------- */
  function strip(h) { return String(h || "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/[ \t]+/g, " ").trim(); }
  function fromClaude(arr) {
    return arr.filter(function (c) { return c && Array.isArray(c.chat_messages); }).map(function (c) {
      return { src: "Claude", title: c.name || "שיחה עם Claude", date: c.created_at || c.updated_at || "",
        msgs: c.chat_messages.map(function (m) {
          var t = m.text || (Array.isArray(m.content) ? m.content.filter(function (x) { return x && x.type === "text"; }).map(function (x) { return x.text; }).join("\n") : "");
          return { r: m.sender === "human" ? "u" : "a", t: String(t || "") };
        }).filter(function (m) { return m.t.trim(); }) };
    });
  }
  function fromChatGPT(arr) {
    return arr.filter(function (c) { return c && c.mapping; }).map(function (c) {
      var msgs = [], node = c.current_node, seen = {};
      while (node && c.mapping[node] && !seen[node]) {
        seen[node] = 1;
        var m = c.mapping[node].message;
        if (m && m.author && (m.author.role === "user" || m.author.role === "assistant") && m.content && Array.isArray(m.content.parts)) {
          var t = m.content.parts.filter(function (x) { return typeof x === "string"; }).join("\n");
          if (t.trim()) msgs.unshift({ r: m.author.role === "user" ? "u" : "a", t: t });
        }
        node = c.mapping[node].parent;
      }
      return { src: "ChatGPT", title: c.title || "שיחה עם ChatGPT", date: c.create_time ? new Date(c.create_time * 1000).toISOString() : "", msgs: msgs };
    });
  }
  function fromGemini(arr) { // Google Takeout "My Activity" — one item per question; grouped by day
    var days = {};
    arr.forEach(function (it) {
      if (!it || !it.title || !/gemini|bard/i.test(String(it.header || "") + " " + String(it.products || ""))) return;
      var q = String(it.title).replace(/^(Prompted|Asked|נשאל|הנחיה)\s*/i, "");
      var a = (it.safeHtmlItem || []).map(function (x) { return strip(x.html); }).join("\n");
      var d = String(it.time || "").slice(0, 10) || "?";
      (days[d] = days[d] || []).push([{ r: "u", t: q }, { r: "a", t: a }]);
    });
    return Object.keys(days).sort().map(function (d) { return { src: "Gemini", title: "Gemini — " + d, date: d, msgs: days[d].reverse().reduce(function (o, pr) { return o.concat(pr); }, []).filter(function (m) { return m.t.trim(); }) }; });
  }
  function detect(name, json) {
    if (!Array.isArray(json)) return [];
    var x = json.find(function (v) { return v && typeof v === "object"; }) || {};
    if (x.chat_messages) return fromClaude(json);
    if (x.mapping) return fromChatGPT(json);
    if (x.header || x.safeHtmlItem || /gemini|MyActivity/i.test(name)) return fromGemini(json);
    return [];
  }

  async function importFile(file, onStep) {
    onStep = onStep || function () {};
    var convs = [];
    if (/\.zip$/i.test(file.name)) {
      onStep("פותח את הקובץ…");
      var files = await unzip(await file.arrayBuffer(), function (n) { return /(^|\/)conversations\.json$/i.test(n) || (/gemini|bard/i.test(n) && /\.json$/i.test(n)); });
      Object.keys(files).forEach(function (n) { try { convs = convs.concat(detect(n, JSON.parse(files[n]))); } catch (e) {} });
    } else {
      onStep("קורא…");
      convs = detect(file.name, JSON.parse(await file.text()));
    }
    convs = convs.filter(function (c) { return c.msgs.length; });
    if (!convs.length) throw new Error("לא מצאתי שיחות בקובץ. צריך את קובץ הייצוא מ-Claude, מ-ChatGPT או מ-Google Takeout (Gemini).");
    onStep("שומר " + convs.length + " שיחות…");
    await tx("readwrite", function (s) {
      convs.forEach(function (c) {
        var id = c.src + ":" + (c.date || "") + ":" + c.title;
        s.put({ id: id, src: c.src, title: String(c.title).slice(0, 200), date: c.date, msgs: c.msgs.map(function (m) { return { r: m.r, t: String(m.t).slice(0, 20000) }; }) });
      });
    });
    var count = {}; convs.forEach(function (c) { count[c.src] = (count[c.src] || 0) + 1; });
    return count;
  }

  /* ---------- search ---------- */
  function words(q) { return String(q || "").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(function (w) { return w.length >= 2; }); }
  async function search(q, src, limit) {
    var W = words(q); if (!W.length) return [];
    var hits = [];
    (await allConvs()).forEach(function (c) {
      if (src && c.src.toLowerCase() !== String(src).toLowerCase()) return;
      var tl = c.title.toLowerCase();
      c.msgs.forEach(function (m, i) {
        var t = m.t.toLowerCase(), sc = 0;
        W.forEach(function (w) { if (t.indexOf(w) >= 0) sc += 2; if (tl.indexOf(w) >= 0) sc += 1; });
        if (sc) hits.push({ sc: sc, c: c, i: i });
      });
    });
    hits.sort(function (a, b) { return b.sc - a.sc; });
    var seen = {}; hits = hits.filter(function (h) { var k = h.c.id + ":" + (h.c.msgs[h.i].r === "u" ? h.i : h.i - 1); if (seen[k]) return false; seen[k] = 1; return true; }); // one hit per question+answer
    return hits.slice(0, limit || 8).map(function (h) {
      var m = h.c.msgs[h.i], other = h.c.msgs[m.r === "u" ? h.i + 1 : h.i - 1];
      return { source: h.c.src, chat: h.c.title, date: String(h.c.date).slice(0, 10), id: h.c.id,
        [m.r === "u" ? "david_said" : "ai_said"]: m.t.slice(0, 1200), [m.r === "u" ? "ai_answered" : "david_asked"]: other ? other.t.slice(0, 800) : "" };
    });
  }
  async function stats() { var c = {}, n = 0; (await allConvs()).forEach(function (x) { c[x.src] = (c[x.src] || 0) + 1; n++; }); return { total: n, by_source: c }; }

  window.DAKB = { importFile: importFile, search: search, stats: stats, read: function (id) { return tx("readonly", function (s) { return s.get(id); }); },
    clear: function () { return tx("readwrite", function (s) { s.clear(); }); } };

  window.DA_KB_TOOLS = [{
    name: "past_chats",
    description: "Search David's past conversations with other AIs (Claude, ChatGPT, Gemini) that he imported into DA.ai. Use it when he asks what he talked about / decided / got from another AI. op: search (q, optional source Claude|ChatGPT|Gemini) | read (id from a search result — whole conversation) | stats.",
    inputSchema: { type: "object", properties: { op: { type: "string", enum: ["search", "read", "stats"] }, q: { type: "string" }, source: { type: "string" }, id: { type: "string" } }, required: ["op"] },
    execute: async function (a) {
      if (a.op === "stats") return stats();
      if (a.op === "read") { var c = await window.DAKB.read(String(a.id || "")); if (!c) return { error: "not found" }; return { source: c.src, title: c.title, date: c.date, messages: c.msgs.slice(0, 60).map(function (m) { return (m.r === "u" ? "דוד: " : "AI: ") + m.t.slice(0, 1500); }) }; }
      var st = await stats(); if (!st.total) return { error: "David has not imported conversations yet. Tell him: פתקים וקבצים ← 📚 ייבוא שיחות." };
      var r = await search(a.q, a.source, 8);
      return r.length ? r : { found: 0, note: "nothing matched — try other words" };
    }
  }];
})();
