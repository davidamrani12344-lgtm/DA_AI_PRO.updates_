/* DA.ai Plan v2.0 — CREDITS (v2.20).
   Every plan gets credits; each action costs credits. The DA.ai server counts and blocks,
   this file only shows the user where they stand (it asks the server).
     trial  — 3 days, 100 credits        free — after the trial, 20 credits a month
     c1000  — 59 ₪ a month               c3000 — 150 ₪ a month          c5000 — 249 ₪ a month
   Costs: 10 messages = 2 · agent action = 4 · picture = 3 · sticker = 3 · 3 voice recordings = 1 ·
          live voice = 2 a minute · file made = 2
   Paid plans are turned on with an activation code the owner makes in the Owner Hub (made on the server). */
(function () {
  "use strict";
  var TRIAL_DAYS = 3;
  var LIMITS = { // labels only — the numbers live on the server
    trial: { label: "ניסיון", credits: 100 }, free: { label: "חינמי", credits: 20 },
    c1000: { label: "1,000 קרדיטים", credits: 1000, price: 59 }, c3000: { label: "3,000 קרדיטים", credits: 3000, price: 150 },
    c5000: { label: "5,000 קרדיטים", credits: 5000, price: 249 }, owner: { label: "בעלים", credits: Infinity },
    pro: { label: "1,000 קרדיטים", credits: 1000 }, vip: { label: "3,000 קרדיטים", credits: 3000 }
  };
  var COST = { message: 0.2, action: 1, image: 4, sticker: 4, voiceNote: 1 / 3, liveMinute: 2, file: 2, song: 12, songClip: 5 };
  var SRV = null; // last answer from the server's /status
  try { SRV = JSON.parse(localStorage.getItem("daai_credits") || "null"); } catch (e) {}
  var OWNER_EMAIL = "davidamrani12344@gmail.com";
  var K = { trial: "daai_trial_start", code: "daai_plan_code", use: "daai_plan_use", ok: "daai_plan_ok" };

  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function pad(n) { return String(n).padStart(2, "0"); }
  function dayKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function monthKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1); }
  function prof() {
    try { if (typeof S !== "undefined" && S && S.profile) return S.profile; } catch (e) {}
    try { var st = JSON.parse(localStorage.getItem("daai_state") || "null"); return (st && st.profile) || null; } catch (e) { return null; }
  }
  function email() { try { return String((prof() && prof().email) || (window.DACloud && DACloud.who() && DACloud.who().email) || "").trim().toLowerCase(); } catch (e) { return ""; } }

  /* ---------- activation codes: DA-P-20270123-1A2B3C4D (checked by the server) ---------- */
  function codeInfo(code) {
    var m = /^DA-([ABCPV])-(\d{8})-([0-9A-F]{8})$/.exec(String(code || "").trim().toUpperCase());
    if (!m) return null;
    return { plan: ({ A: "c1000", B: "c3000", C: "c5000", P: "c1000", V: "c3000" })[m[1]], exp: new Date(+m[2].slice(0, 4), +m[2].slice(4, 6) - 1, +m[2].slice(6, 8), 23, 59, 59) };
  }
  // the server says whether the saved code is valid for this Google account
  async function verify(code) {
    if (!(window.DAServer && DAServer.url())) return { ok: false, why: "offline" };
    var r = await DAServer.call("/status");
    var j = await r.json().catch(function () { return {}; });
    if (!r.ok) return { ok: false, why: r.status === 401 ? "no-email" : "offline" };
    gotStatus(j);
    if (/^c\d+$/.test(j.plan)) {
      var exp = j.until ? new Date(j.until) : (codeInfo(code) || {}).exp;
      ls(K.ok, JSON.stringify({ code: String(code).trim().toUpperCase(), plan: j.plan, exp: exp ? exp.getTime() : 0, email: email() }));
      return { ok: true, plan: j.plan, exp: exp };
    }
    return { ok: false, why: "mismatch" };
  }
  async function activate(code) {
    var info = codeInfo(code);
    if (!info) return { ok: false, why: "format" };
    if (!email()) return { ok: false, why: "no-email" };
    if (info.exp.getTime() < Date.now()) return { ok: false, why: "expired" };
    var prev = ls(K.code);
    ls(K.code, String(code).trim().toUpperCase());
    var r = await verify(code).catch(function () { return { ok: false, why: "offline" }; });
    if (!r.ok && r.why !== "offline") { if (prev) ls(K.code, prev); else ls(K.code, null); }
    return r;
  }
  // owner only: the server makes the code
  async function makeCode(mail, plan, months) {
    var r = await DAServer.call("/plan/code", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: mail, plan: plan, months: Number(months) || 1 }) });
    var j = await r.json().catch(function () { return {}; });
    if (!r.ok || !j.code) throw new Error(r.status === 403 ? "רק הבעלים יכול ליצור קודים" : "השרת לא זמין");
    return j.code;
  }

  /* ---------- trial ---------- */
  function trialStart() {
    var t = Number(ls(K.trial)) || 0;
    if (!t) { t = Date.now(); ls(K.trial, String(t)); }
    return t;
  }
  // keep the earliest start we know of (local or cloud) so reinstalling doesn't restart the trial
  function mergeTrialStart(t) { t = Number(t) || 0; if (t > 0 && t < trialStart()) ls(K.trial, String(t)); }
  function trialLeftMs() { return trialStart() + TRIAL_DAYS * 864e5 - Date.now(); }

  /* ---------- where the user stands (from the server) ---------- */
  function gotStatus(j) {
    if (!j || !j.plan) return;
    // v2.48: the subscription was just opened for this account → tell the user
    try {
      var was = SRV && SRV.plan, paidNow = /^c\d/.test(j.plan);
      if (paidNow && was && was !== j.plan && window.toast) window.toast("🎉 המנוי שלך נפתח: " + (j.label || j.plan) + " — תודה!", "סגור", null, true);
      // v2.49: 3 days before the subscription ends — remind once a day, with a button to renew on WhatsApp
      var left = j.until ? j.until - Date.now() : 0, day = new Date().toISOString().slice(0, 10);
      if (paidNow && left > 0 && left < 3 * 864e5 && localStorage.getItem("daai_renew_day") !== day && window.toast) {
        localStorage.setItem("daai_renew_day", day);
        var d = Math.max(1, Math.ceil(left / 864e5));
        window.toast("⏰ המנוי שלך מסתיים בעוד " + d + (d === 1 ? " יום" : " ימים") + " — רוצה לחדש?", "חדש עכשיו", function () { if (window.contactDavid) window.contactDavid("חידוש מנוי " + (j.label || j.plan)); }, true);
      }
    } catch (e) {}
    SRV = { plan: j.plan, label: j.label, left: j.creditsLeft, credits: j.credits, until: j.until, trialStart: j.trialStart, at: Date.now() };
    ls("daai_credits", JSON.stringify(SRV));
  }
  var refreshing = null;
  function refresh() {
    if (refreshing) return refreshing;
    if (!(window.DAServer && DAServer.url())) return Promise.resolve(null);
    refreshing = DAServer.call("/status").then(function (r) { return r.ok ? r.json() : null; }).then(function (j) { if (j) gotStatus(j); render(); return j; })
      .catch(function () { return null; }).then(function (j) { refreshing = null; return j; });
    return refreshing;
  }
  function ownKeyUser() {
    try {
      if (window.DA_ENGINE === "claude") return true;
      var own = (localStorage.getItem("daai_gemini_key") || "").trim();
      if (own && own !== window.DEFAULT_GEMINI_KEY) return true; // pays with own key — the server isn't used
      if ((localStorage.getItem("daai_claude_key") || "").trim()) return true;
    } catch (e) {}
    return false;
  }
  function plan() {
    if (ownKeyUser()) return "owner";
    if (SRV && SRV.plan) return SRV.plan;
    return trialLeftMs() > 0 ? "trial" : "free";
  }
  function paid() { var p = plan(); return /^c\d+$/.test(p) && SRV ? { plan: p, exp: SRV.until ? new Date(SRV.until) : null } : null; }
  function status() {
    var p = plan(), L = LIMITS[p] || LIMITS.free;
    var left = p === "owner" ? Infinity : (SRV && SRV.left != null ? SRV.left : L.credits);
    var s = { plan: p, label: L.label, credits: L.credits, left: left,
      // kept for older code that still reads these
      msgLeft: left === Infinity ? Infinity : Math.floor(left / COST.message), msgLimit: L.credits, voiceLeftSec: left === Infinity ? Infinity : Math.floor(left / COST.liveMinute) * 60 };
    if (p === "trial") s.trialDaysLeft = Math.max(1, Math.ceil(trialLeftMs() / 864e5));
    if (SRV && SRV.until && /^c\d+$/.test(p)) s.until = new Date(SRV.until);
    return s;
  }
  // the server blocks for real; here we only stop early when we already know the credits are gone
  function useMessage() { var s = status(); if (s.plan === "owner" || s.left >= COST.message) { setTimeout(refresh, 4000); return true; } refresh(); render(); return false; }
  function useImage(kind) { var s = status(); return s.plan === "owner" || s.left >= (kind === "sticker" ? COST.sticker : COST.image); }
  function canVoice() { var s = status(); return s.plan === "owner" || s.left >= COST.liveMinute; }
  function addVoice() { setTimeout(refresh, 2000); }
  // things made on the phone (files, reports): ask the server to charge first
  async function charge(kind) {
    if (plan() === "owner") return true;
    if (!(window.DAServer && DAServer.url())) return true;
    var r = await DAServer.call("/charge", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: kind }) });
    if (r.status === 429) { refresh(); return false; }
    var j = await r.json().catch(function () { return {}; });
    if (j && j.creditsLeft != null && SRV) { SRV.left = j.creditsLeft; ls("daai_credits", JSON.stringify(SRV)); render(); }
    return true;
  }
  function blockedText(kind) {
    var s = status();
    var who = (function () { try { return (prof() && prof().name) ? prof().name.split(" ")[0] + ", " : ""; } catch (e) { return ""; } })();
    if (s.plan === "trial") return "⏳ " + who + "נגמרו 100 קרדיטי הניסיון.\n\nכדי להמשיך — בחר חבילת קרדיטים בלחיצה על 💎.";
    if (s.plan === "free") return "⏳ " + who + "נגמרו הקרדיטים החינמיים של החודש.\n\nכדי להמשיך — בחר חבילת קרדיטים בלחיצה על 💎.";
    return "⏳ " + who + "נגמרו הקרדיטים של החודש בחבילה שלך. הקרדיטים מתחדשים בתחילת החודש — או שדרג לחבילה גדולה יותר ב-💎.";
  }
  function fmtCr(n) { return n === Infinity ? "∞" : (Math.floor(n * 10) / 10).toLocaleString("he-IL"); }

  /* ---------- UI: small status pill + activation box inside the subscription window ---------- */
  function fmtMin(sec) { return sec === Infinity ? "∞" : Math.floor(sec / 60) + " דק׳"; }
  function render() {
    try {
      var s = status();
      var pill = document.getElementById("daPlanPill");
      if (!pill && !document.getElementById("inp")) return; // pill only on the main chat screen
      if (!pill) {
        pill = document.createElement("button");
        pill.id = "daPlanPill"; pill.type = "button";
        // v2.41.3: sits on the same line as the DA.ai button (above the message bar), never on top of it
        pill.style.cssText = "margin-inline-start:auto;border:1px solid #d4af37;border-radius:14px;padding:3px 10px;font-size:11px;font-weight:700;background:rgba(17,20,30,.85);color:#f0d488;direction:rtl;cursor:pointer;max-width:58vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis";
        pill.onclick = function () { if (typeof window.openSubModal === "function") window.openSubModal(); };
        var bar = document.getElementById("glStarBar");
        if (bar) bar.appendChild(pill); else { pill.style.cssText += ";position:fixed;bottom:calc(env(safe-area-inset-bottom,0px) + 152px);left:10px;z-index:40"; document.body.appendChild(pill); }
      }
      if (s.plan === "owner") { pill.style.display = "none"; }
      else {
        pill.style.display = "";
        if (s.plan === "trial") pill.textContent = "🎁 ניסיון · " + fmtCr(s.left) + " קרדיטים · " + (s.trialDaysLeft === 1 ? "יום אחרון" : "עוד " + s.trialDaysLeft + " ימים");
        else if (s.plan === "free") pill.textContent = "⏳ " + fmtCr(s.left) + " קרדיטים · לרכישה 💎";
        else pill.textContent = "💎 " + fmtCr(s.left) + " / " + fmtCr(s.credits) + " קרדיטים";
      }
      renderBox(s);
    } catch (e) {}
  }
  function renderBox(s) {
    var modal = document.getElementById("subModal"); if (!modal) return;
    var box = document.getElementById("daPlanBox");
    if (!box) {
      box = document.createElement("div"); box.id = "daPlanBox";
      box.style.cssText = "background:#fdfbf7;border:1.5px solid #d4af37;border-radius:12px;padding:10px 12px;margin-bottom:14px;font-size:13px;color:#111827;direction:rtl";
      var head = modal.firstElementChild && modal.firstElementChild.nextElementSibling;
      modal.insertBefore(box, head || modal.firstChild);
    }
    var line;
    if (s.plan === "owner") line = "👑 גישה מלאה ללא הגבלה.";
    else if (s.plan === "trial") line = "🎁 <b>ניסיון חינם</b> — נותרו " + s.trialDaysLeft + " ימים ו-<b>" + fmtCr(s.left) + "</b> קרדיטים מתוך 100.";
    else if (s.plan === "free") line = "⏳ <b>תקופת הניסיון הסתיימה.</b> נותרו " + fmtCr(s.left) + " קרדיטים חינמיים החודש.";
    else line = "💎 <b>חבילת " + s.label + "</b>" + (s.until ? " עד " + s.until.toLocaleDateString("he-IL") : "") + " · נותרו <b>" + fmtCr(s.left) + "</b> קרדיטים החודש.";
    line += '<div style="margin-top:6px;font-size:12px;font-weight:500;color:#4b5563;line-height:1.6">כמה זה עולה: 10 הודעות = 2 · פעולה (תזכורת, משימה, הוצאה) = 1 · 3 הקלטות או הקראות = 1 · שיחה קולית = 2 לדקה · תמונה = 4 · שיר מלא = 12 · קובץ = 2</div>';
    box.innerHTML = '<div style="line-height:1.6;font-weight:600">' + line + '</div>' +
      (s.plan === "owner" ? "" :
      '<div style="display:flex;gap:6px;margin-top:8px"><input id="daPlanCode" placeholder="יש לך קוד הפעלה? DA-A-..." style="flex:1;min-width:0;padding:8px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;direction:ltr;text-align:left;background:#fff;color:#111">' +
      '<button type="button" id="daPlanAct" style="padding:8px 12px;border:none;border-radius:8px;background:linear-gradient(135deg,#b8892c,#f0d488);color:#000;font-weight:800;cursor:pointer">הפעל</button></div>' +
      '<small style="display:block;margin-top:6px;color:#4b5563">אחרי התשלום דוד שולח לך קוד הפעלה בוואטסאפ. הקוד עובד עם חשבון ה-Google שאיתו נכנסת לאפליקציה.</small>');
    var b = document.getElementById("daPlanAct");
    if (b) b.onclick = function () {
      var v = (document.getElementById("daPlanCode") || {}).value || "";
      b.disabled = true;
      activate(v).then(function (r) {
      b.disabled = false;
      var msg = r.ok ? "✅ חבילת " + (LIMITS[r.plan] || {}).label + " הופעלה" + (r.exp ? " עד " + r.exp.toLocaleDateString("he-IL") : "")
        : r.why === "no-email" ? "כדי להפעיל קוד צריך קודם להתחבר עם Google (בפרופיל)."
        : r.why === "expired" ? "הקוד הזה כבר פג תוקף."
        : r.why === "mismatch" ? "הקוד לא מתאים לחשבון " + (email() || "") + ". בדוק שנכנסת עם אותו מייל ששלחת לדוד."
        : r.why === "offline" ? "אין חיבור לשרת כרגע. הקוד נשמר ויופעל כשיהיה חיבור."
        : "הקוד לא תקין. בדוק שהעתקת אותו במלואו.";
      if (typeof toast === "function") toast(msg); else alert(msg);
      render();
      });
    };
  }

  /* ---------- Owner Hub: code generator ---------- */
  function ownerTools() {
    var hub = document.getElementById("secOwnerHub"); if (!hub || document.getElementById("daPlanGen")) return;
    var d = document.createElement("div"); d.id = "daPlanGen";
    d.style.cssText = "margin-top:10px;padding-top:8px;border-top:1px dashed #f0d488;font-size:12px";
    d.innerHTML = '<b style="color:#f0d488;display:block;margin-bottom:5px">🔑 קוד הפעלה למנוי</b>' +
      '<input id="daGenMail" placeholder="מייל ה-Google של הלקוח" style="width:100%;box-sizing:border-box;padding:6px;border-radius:6px;margin-bottom:5px;direction:ltr">' +
      '<div style="display:flex;gap:4px;margin-bottom:5px"><select id="daGenPlan" style="flex:1;padding:6px;border-radius:6px"><option value="c1000">1,000 קרדיטים · 59 ₪</option><option value="c3000">3,000 קרדיטים · 150 ₪</option><option value="c5000">5,000 קרדיטים · 249 ₪</option></select>' +
      '<select id="daGenMonths" style="flex:1;padding:6px;border-radius:6px"><option value="1">חודש</option><option value="3">3 חודשים</option><option value="12">שנה</option></select></div>' +
      '<button type="button" class="btn" id="daGenBtn" style="width:100%;font-size:12px;padding:7px">צור קוד ושלח בוואטסאפ</button>' +
      '<div id="daGenOut" style="margin-top:5px;direction:ltr;text-align:left;font-weight:800;color:#55ffaa;user-select:all"></div>';
    hub.appendChild(d);
    document.getElementById("daGenBtn").onclick = function () {
      var mail = document.getElementById("daGenMail").value.trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) { alert("הכנס מייל תקין של הלקוח"); return; }
      var pl = document.getElementById("daGenPlan").value, mo = document.getElementById("daGenMonths").value;
      var btn = this; btn.disabled = true;
      makeCode(mail, pl, mo).then(function (code) {
      btn.disabled = false;
      document.getElementById("daGenOut").textContent = code;
      try { navigator.clipboard && navigator.clipboard.writeText(code); } catch (e) {}
      var text = "תודה על ההצטרפות ל-DA.ai 💎\nקוד ההפעלה שלך: " + code + "\nבאפליקציה: לחץ על 💎 ← הדבק את הקוד ← הפעל.\n(הקוד עובד עם החשבון " + mail + ")";
      if (confirm("הקוד הועתק: " + code + "\n\nלפתוח וואטסאפ כדי לשלוח ללקוח?")) {
        var url = "https://wa.me/?text=" + encodeURIComponent(text);
        if (window.AndroidApp && window.AndroidApp.openUrl) window.AndroidApp.openUrl(url); else window.open(url, "_blank");
      }
      }).catch(function (e) { btn.disabled = false; alert("לא נוצר קוד: " + e.message); });
    };
  }

  // cloud: keep the trial start on the user's account so a reinstall doesn't give a new trial
  async function syncTrial() {
    try { if (window.DACloud && DACloud.trialStart) mergeTrialStart(await DACloud.trialStart(trialStart())); } catch (e) {}
    render();
  }

  window.DAPlan = { refresh: refresh, charge: charge, COST: COST, status: status, plan: plan, useMessage: useMessage, useImage: useImage, canVoice: canVoice, addVoice: addVoice, blockedText: blockedText, activate: activate, makeCode: makeCode, render: render, syncTrial: syncTrial, LIMITS: LIMITS };

  document.addEventListener("DOMContentLoaded", function () {
    trialStart();
    setTimeout(function () { render(); ownerTools(); }, 900);
    setTimeout(syncTrial, 4000);
    setTimeout(refresh, 2500);
    setInterval(function () { render(); ownerTools(); }, 60000);
  });
})();
