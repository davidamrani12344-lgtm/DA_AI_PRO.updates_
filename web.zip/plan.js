/* DA.ai Plan v1.0 — 3-day free trial + usage limits per plan.
   Plans:
     owner  — David (admin role / owner email / own API key / running inside Claude): no limits
     trial  — first 3 days: 40 messages a day, 10 minutes of live voice a day
     free   — after the trial: 5 messages a day, no live voice (classic voice still works, counts as messages)
     pro    — 49 ₪: 300 messages a day (fair use), 30 minutes of live voice a month
     vip    — 99 ₪: 500 messages a day (fair use), 60 minutes of live voice a day
   Paid plans are turned on with an activation code the owner makes in the Owner Hub
   (the code is tied to the customer's Google e-mail and has an end date). */
(function () {
  "use strict";
  var TRIAL_DAYS = 3;
  var LIMITS = {
    trial: { imgDay: 10, msgDay: 40, voiceDaySec: 10 * 60, voiceMonthSec: Infinity, label: "ניסיון חינם" },
    free:  { imgDay: 0, msgDay: 5, voiceDaySec: 0, voiceMonthSec: 0, label: "חינמי" },
    pro:   { imgDay: 20, msgDay: 300, voiceDaySec: Infinity, voiceMonthSec: 30 * 60, label: "Pro" },
    vip:   { imgDay: 60, msgDay: 500, voiceDaySec: 60 * 60, voiceMonthSec: Infinity, label: "Business VIP" },
    owner: { imgDay: Infinity, msgDay: Infinity, voiceDaySec: Infinity, voiceMonthSec: Infinity, label: "בעלים" }
  };
  var OWNER_EMAIL = "davidamrani12344@gmail.com";
  var SECRET = "DA.ai|plan|7f3c91e2|amrani";
  var K = { trial: "daai_trial_start", code: "daai_plan_code", use: "daai_plan_use" };

  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function pad(n) { return String(n).padStart(2, "0"); }
  function dayKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function monthKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1); }
  function prof() {
    try { if (typeof S !== "undefined" && S && S.profile) return S.profile; } catch (e) {}
    try { var st = JSON.parse(localStorage.getItem("daai_state") || "null"); return (st && st.profile) || null; } catch (e) { return null; }
  }
  function email() { try { return String((prof() && prof().email) || (window.DACloud && DACloud.who() && DACloud.who().email) || "").trim().toLowerCase(); } catch (e) { return ""; } }

  // small dependency-free hash (works in any WebView, no crypto.subtle needed)
  function h53(str, seed) {
    var h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (var i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).toUpperCase().padStart(14, "0");
  }
  function sig(mail, plan, exp) { return h53(SECRET + "|" + mail + "|" + plan + "|" + exp, 7).slice(-8); }

  /* ---------- activation codes: DA-P-20270123-1A2B3C4D ---------- */
  function makeCode(mail, plan, months) {
    mail = String(mail || "").trim().toLowerCase();
    plan = plan === "vip" ? "V" : "P";
    var d = new Date(); d.setMonth(d.getMonth() + (Number(months) || 1)); d.setDate(d.getDate() + 1);
    var exp = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate());
    return "DA-" + plan + "-" + exp + "-" + sig(mail, plan, exp);
  }
  function parseCode(code, mail) {
    var m = /^DA-([PV])-(\d{8})-([0-9A-F]{8})$/.exec(String(code || "").trim().toUpperCase());
    if (!m) return { ok: false, why: "format" };
    if (!mail) return { ok: false, why: "no-email" };
    if (sig(mail, m[1], m[2]) !== m[3]) return { ok: false, why: "mismatch" };
    var exp = new Date(+m[2].slice(0, 4), +m[2].slice(4, 6) - 1, +m[2].slice(6, 8), 23, 59, 59);
    if (exp.getTime() < Date.now()) return { ok: false, why: "expired", exp: exp };
    return { ok: true, plan: m[1] === "V" ? "vip" : "pro", exp: exp };
  }
  function activate(code) {
    var r = parseCode(code, email());
    if (r.ok) ls(K.code, String(code).trim().toUpperCase());
    return r;
  }

  /* ---------- trial ---------- */
  function trialStart() {
    var t = Number(ls(K.trial)) || 0;
    if (!t) { t = Date.now(); ls(K.trial, String(t)); }
    return t;
  }
  // keep the earliest start we know of (local or cloud) so reinstalling doesn't restart the trial
  function mergeTrialStart(t) { t = Number(t) || 0; if (t > 0 && t < trialStart()) ls(K.trial, String(t)); }
  function trialLeftMs() { return trialStart() + TRIAL_DAYS * 864e5 - Date.now(); }

  /* ---------- who pays? ---------- */
  function unlimited() {
    try {
      if (localStorage.getItem("daai_role") === "admin") return true;
      if (email() === OWNER_EMAIL) return true;
      if (window.DA_ENGINE === "claude") return true;            // running inside Claude — not on David's keys
      var own = (localStorage.getItem("daai_gemini_key") || "").trim();
      if (own && own !== window.DEFAULT_GEMINI_KEY) return true; // user pays with own key
      if ((localStorage.getItem("daai_claude_key") || "").trim()) return true;
    } catch (e) {}
    return false;
  }
  function paid() { var c = ls(K.code); if (!c) return null; var r = parseCode(c, email()); return r.ok ? r : null; }
  function plan() {
    if (unlimited()) return "owner";
    var p = paid(); if (p) return p.plan;
    return trialLeftMs() > 0 ? "trial" : "free";
  }

  /* ---------- usage counters ---------- */
  function usage() {
    var u; try { u = JSON.parse(ls(K.use) || "{}"); } catch (e) { u = {}; }
    var d = dayKey(), m = monthKey();
    if (u.day !== d) { u.day = d; u.msg = 0; u.vDay = 0; u.img = 0; }
    if (u.month !== m) { u.month = m; u.vMonth = 0; }
    return u;
  }
  function saveUse(u) { ls(K.use, JSON.stringify(u)); }

  function status() {
    var p = plan(), L = LIMITS[p], u = usage();
    var voiceLeft = Math.max(0, Math.min(L.voiceDaySec - (u.vDay || 0), L.voiceMonthSec - (u.vMonth || 0)));
    var s = { plan: p, label: L.label, msgUsed: u.msg || 0, msgLimit: L.msgDay, msgLeft: Math.max(0, L.msgDay - (u.msg || 0)), voiceLeftSec: voiceLeft };
    if (p === "trial") s.trialDaysLeft = Math.max(1, Math.ceil(trialLeftMs() / 864e5));
    var pd = paid(); if (pd && (p === "pro" || p === "vip")) s.until = pd.exp;
    return s;
  }

  // call before a chat message / classic-voice turn; returns true and counts it, or false when the limit is reached
  function useMessage() {
    var s = status();
    if (s.plan === "owner") return true;
    if (s.msgLeft <= 0) { render(); return false; }
    var u = usage(); u.msg = (u.msg || 0) + 1; saveUse(u); render();
    return true;
  }
  // AI-drawn stickers (Gemini image) — the most expensive call per use
  function useImage() {
    var p = plan(), L = LIMITS[p]; if (p === "owner") return true;
    var u = usage(); if ((u.img || 0) >= L.imgDay) return false;
    u.img = (u.img || 0) + 1; saveUse(u); return true;
  }
  function canVoice() { var s = status(); return s.plan === "owner" || s.voiceLeftSec > 0; }
  function addVoice(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0)); if (!sec || plan() === "owner") return;
    var u = usage(); u.vDay = (u.vDay || 0) + sec; u.vMonth = (u.vMonth || 0) + sec; saveUse(u); render();
  }

  function blockedText(kind) {
    var s = status();
    var who = (function () { try { return (prof() && prof().name) ? prof().name.split(" ")[0] + ", " : ""; } catch (e) { return ""; } })();
    if (kind === "voice") {
      if (s.plan === "free") return who + "השיחה הקולית החיה פתוחה למנויים. ממשיך בשיחה רגילה — לשדרוג לחץ על 💎.";
      return who + "נגמרו דקות השיחה החיה " + (s.plan === "pro" ? "לחודש הזה" : "להיום") + ". ממשיך בשיחה רגילה.";
    }
    if (s.plan === "free") return "⏳ " + who + "תקופת הניסיון של 3 ימים הסתיימה, וניצלת את " + s.msgLimit + " ההודעות החינמיות של היום.\n\nכדי להמשיך בלי הגבלה — בחר מסלול 💎 (Pro מ-49 ₪ לחודש). מחר יתחדשו " + s.msgLimit + " הודעות חינם.";
    if (s.plan === "trial") return "⏳ " + who + "הגעת למכסה היומית של תקופת הניסיון (" + s.msgLimit + " הודעות). המכסה מתחדשת מחר — או שדרג עכשיו ותמשיך בלי לחכות 💎.";
    return "⏳ " + who + "הגעת למכסה היומית של המסלול (" + s.msgLimit + " הודעות). המכסה מתחדשת מחר.";
  }

  /* ---------- UI: small status pill + activation box inside the subscription window ---------- */
  function fmtMin(sec) { return sec === Infinity ? "∞" : Math.floor(sec / 60) + " דק׳"; }
  function render() {
    try {
      var s = status();
      var pill = document.getElementById("daPlanPill");
      if (!pill && !document.getElementById("inp")) return; // pill only on the main chat screen
      if (!pill) {
        pill = document.createElement("button");
        pill.id = "daPlanPill"; pill.type = "button";
        pill.style.cssText = "position:fixed;bottom:calc(env(safe-area-inset-bottom,0px) + 152px);left:10px;z-index:40;border:1px solid #d4af37;border-radius:14px;padding:3px 10px;font-size:11px;font-weight:700;background:rgba(17,20,30,.85);color:#f0d488;direction:rtl;cursor:pointer;max-width:70vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis";
        pill.onclick = function () { if (typeof window.openSubModal === "function") window.openSubModal(); };
        document.body.appendChild(pill);
      }
      if (s.plan === "owner") { pill.style.display = "none"; }
      else {
        pill.style.display = "";
        if (s.plan === "trial") pill.textContent = "🎁 ניסיון: " + (s.trialDaysLeft === 1 ? "יום אחרון" : "עוד " + s.trialDaysLeft + " ימים") + " · " + s.msgLeft + " הודעות היום";
        else if (s.plan === "free") pill.textContent = "⏳ הניסיון הסתיים · " + s.msgLeft + "/" + s.msgLimit + " היום · שדרג 💎";
        else pill.textContent = "💎 " + s.label + (s.until ? " עד " + s.until.toLocaleDateString("he-IL") : "");
      }
      renderBox(s);
    } catch (e) {}
  }
  function renderBox(s) {
    var modal = document.getElementById("subModal"); if (!modal) return;
    var box = document.getElementById("daPlanBox");
    if (!box) {
      box = document.createElement("div"); box.id = "daPlanBox";
      box.style.cssText = "background:#fdfbf7;border:1.5px solid #d4af37;border-radius:12px;padding:10px 12px;margin-bottom:14px;font-size:13px;color:#111827;direction:rtl";
      var head = modal.firstElementChild && modal.firstElementChild.nextElementSibling;
      modal.insertBefore(box, head || modal.firstChild);
    }
    var line;
    if (s.plan === "owner") line = "👑 גישה מלאה ללא הגבלה.";
    else if (s.plan === "trial") line = "🎁 <b>3 ימי ניסיון חינם</b> — נותרו " + s.trialDaysLeft + " ימים. היום: " + s.msgLeft + " מתוך " + s.msgLimit + " הודעות, " + fmtMin(s.voiceLeftSec) + " שיחה חיה.";
    else if (s.plan === "free") line = "⏳ <b>תקופת הניסיון הסתיימה.</b> במסלול החינמי: " + s.msgLimit + " הודעות ביום, בלי שיחה חיה. נשארו היום: " + s.msgLeft + ".";
    else line = "💎 <b>מסלול " + s.label + " פעיל</b>" + (s.until ? " עד " + s.until.toLocaleDateString("he-IL") : "") + ". היום: " + s.msgLeft + " הודעות, שיחה חיה: " + fmtMin(s.voiceLeftSec) + ".";
    box.innerHTML = '<div style="line-height:1.6;font-weight:600">' + line + '</div>' +
      (s.plan === "owner" ? "" :
      '<div style="display:flex;gap:6px;margin-top:8px"><input id="daPlanCode" placeholder="יש לך קוד הפעלה? DA-P-..." style="flex:1;min-width:0;padding:8px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;direction:ltr;text-align:left;background:#fff;color:#111">' +
      '<button type="button" id="daPlanAct" style="padding:8px 12px;border:none;border-radius:8px;background:linear-gradient(135deg,#b8892c,#f0d488);color:#000;font-weight:800;cursor:pointer">הפעל</button></div>' +
      '<small style="display:block;margin-top:6px;color:#4b5563">אחרי התשלום דוד שולח לך קוד הפעלה בוואטסאפ. הקוד עובד עם חשבון ה-Google שאיתו נכנסת לאפליקציה.</small>');
    var b = document.getElementById("daPlanAct");
    if (b) b.onclick = function () {
      var v = (document.getElementById("daPlanCode") || {}).value || "";
      var r = activate(v);
      var msg = r.ok ? "✅ המסלול " + LIMITS[r.plan].label + " הופעל עד " + r.exp.toLocaleDateString("he-IL")
        : r.why === "no-email" ? "כדי להפעיל קוד צריך קודם להתחבר עם Google (בפרופיל)."
        : r.why === "expired" ? "הקוד הזה כבר פג תוקף."
        : r.why === "mismatch" ? "הקוד לא מתאים לחשבון " + (email() || "") + ". בדוק שנכנסת עם אותו מייל ששלחת לדוד."
        : "הקוד לא תקין. בדוק שהעתקת אותו במלואו.";
      if (typeof toast === "function") toast(msg); else alert(msg);
      render();
    };
  }

  /* ---------- Owner Hub: code generator ---------- */
  function ownerTools() {
    var hub = document.getElementById("secOwnerHub"); if (!hub || document.getElementById("daPlanGen")) return;
    var d = document.createElement("div"); d.id = "daPlanGen";
    d.style.cssText = "margin-top:10px;padding-top:8px;border-top:1px dashed #f0d488;font-size:12px";
    d.innerHTML = '<b style="color:#f0d488;display:block;margin-bottom:5px">🔑 קוד הפעלה למנוי</b>' +
      '<input id="daGenMail" placeholder="מייל ה-Google של הלקוח" style="width:100%;box-sizing:border-box;padding:6px;border-radius:6px;margin-bottom:5px;direction:ltr">' +
      '<div style="display:flex;gap:4px;margin-bottom:5px"><select id="daGenPlan" style="flex:1;padding:6px;border-radius:6px"><option value="pro">Pro 49 ₪</option><option value="vip">VIP 99 ₪</option></select>' +
      '<select id="daGenMonths" style="flex:1;padding:6px;border-radius:6px"><option value="1">חודש</option><option value="3">3 חודשים</option><option value="12">שנה</option></select></div>' +
      '<button type="button" class="btn" id="daGenBtn" style="width:100%;font-size:12px;padding:7px">צור קוד ושלח בוואטסאפ</button>' +
      '<div id="daGenOut" style="margin-top:5px;direction:ltr;text-align:left;font-weight:800;color:#55ffaa;user-select:all"></div>';
    hub.appendChild(d);
    document.getElementById("daGenBtn").onclick = function () {
      var mail = document.getElementById("daGenMail").value.trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) { alert("הכנס מייל תקין של הלקוח"); return; }
      var pl = document.getElementById("daGenPlan").value, mo = document.getElementById("daGenMonths").value;
      var code = makeCode(mail, pl, mo);
      document.getElementById("daGenOut").textContent = code;
      try { navigator.clipboard && navigator.clipboard.writeText(code); } catch (e) {}
      var text = "תודה על ההצטרפות ל-DA.ai 💎\nקוד ההפעלה שלך: " + code + "\nבאפליקציה: לחץ על 💎 ← הדבק את הקוד ← הפעל.\n(הקוד עובד עם החשבון " + mail + ")";
      if (confirm("הקוד הועתק: " + code + "\n\nלפתוח וואטסאפ כדי לשלוח ללקוח?")) {
        var url = "https://wa.me/?text=" + encodeURIComponent(text);
        if (window.AndroidApp && window.AndroidApp.openUrl) window.AndroidApp.openUrl(url); else window.open(url, "_blank");
      }
    };
  }

  // cloud: keep the trial start on the user's account so a reinstall doesn't give a new trial
  async function syncTrial() {
    try { if (window.DACloud && DACloud.trialStart) mergeTrialStart(await DACloud.trialStart(trialStart())); } catch (e) {}
    render();
  }

  window.DAPlan = { status: status, plan: plan, useMessage: useMessage, useImage: useImage, canVoice: canVoice, addVoice: addVoice, blockedText: blockedText, activate: activate, makeCode: makeCode, render: render, syncTrial: syncTrial, LIMITS: LIMITS };

  document.addEventListener("DOMContentLoaded", function () {
    trialStart();
    setTimeout(function () { render(); ownerTools(); }, 900);
    setTimeout(syncTrial, 4000);
    setInterval(function () { render(); ownerTools(); }, 60000);
  });
})();
