/* DA.ai Cloud Sync v1.0 — shared conversation log across all users (Firebase).
   Each user's app stores its own messages in Firestore; only the owner (by email) can read them all.
   Config (not secret — Firebase web keys are public by design) is pasted once by the owner.
   Auth: the native Google ID token is exchanged for a Firebase token (signInWithIdp). */
(function () {
  "use strict";
  const LS = {
    cfg: "daai_cloud_cfg",         // {apiKey, projectId, ownerEmail}
    fb: "daai_cloud_fb",           // {idToken, refreshToken, uid, email, exp}
    consent: "daai_cloud_consent"  // "1" once the user has agreed
  };

  // Baked-in public config (filled in once the owner sets up Firebase). Firebase web keys are public by design.
  // When set, every user's app logs to the same project automatically. Owner can still override on-device.
  const DEFAULT_CLOUD = { apiKey: "AIzaSyBjSqBgt8Z6FogTVF9IeEc2OK9VWK8xc64", projectId: "da-ai-514221", ownerEmail: "davidamrani12344@gmail.com" };
  function cfg() {
    // the baked-in config is authoritative — ignore any stale per-device key saved before setup
    if (DEFAULT_CLOUD.apiKey) return DEFAULT_CLOUD;
    try { const c = JSON.parse(localStorage.getItem(LS.cfg) || "null"); if (c && c.apiKey) return c; } catch (e) {}
    return null;
  }
  // one-time cleanup: drop a stale saved config that doesn't match the baked key
  (function () {
    try {
      if (!DEFAULT_CLOUD.apiKey) return;
      var c = JSON.parse(localStorage.getItem(LS.cfg) || "null");
      if (c && c.apiKey && c.apiKey !== DEFAULT_CLOUD.apiKey) { localStorage.removeItem(LS.cfg); localStorage.removeItem(LS.fb); }
    } catch (e) {}
  })();
  function setCfg(c) { try { localStorage.setItem(LS.cfg, JSON.stringify(c)); } catch (e) {} }
  function enabled() { const c = cfg(); return !!(c && c.apiKey && c.projectId); }
  function consented() { try { return localStorage.getItem(LS.consent) === "1"; } catch (e) { return false; } }
  function setConsent(v) { try { localStorage.setItem(LS.consent, v ? "1" : "0"); } catch (e) {} }

  let fb = null;
  try { fb = JSON.parse(localStorage.getItem(LS.fb) || "null"); } catch (e) {}
  function saveFb(x) { fb = x; try { localStorage.setItem(LS.fb, JSON.stringify(x)); } catch (e) {} }

  async function jpost(url, body) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || ("HTTP " + r.status));
    return j;
  }

  // Exchange a Google ID token (JWT from native sign-in) for a Firebase session.
  async function linkGoogle(googleIdToken, email) {
    const c = cfg(); if (!(c && c.apiKey)) throw new Error("no-config");
    if (!googleIdToken) throw new Error("no-google-token");
    const j = await jpost("https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=" + encodeURIComponent(c.apiKey), {
      postBody: "id_token=" + encodeURIComponent(googleIdToken) + "&providerId=google.com",
      requestUri: "https://" + c.projectId + ".firebaseapp.com",
      returnSecureToken: true, returnIdpCredential: true
    });
    saveFb({ idToken: j.idToken, refreshToken: j.refreshToken, uid: j.localId, email: j.email || email || "", exp: Date.now() + (Number(j.expiresIn || 3600) - 60) * 1000 });
    return fb;
  }

  async function freshToken() {
    const c = cfg(); if (!(c && c.apiKey) || !fb) throw new Error("not-linked");
    if (fb.idToken && Date.now() < fb.exp) return fb.idToken;
    if (!fb.refreshToken) throw new Error("not-linked");
    const j = await jpost("https://securetoken.googleapis.com/v1/token?key=" + encodeURIComponent(c.apiKey),
      { grant_type: "refresh_token", refresh_token: fb.refreshToken });
    saveFb(Object.assign({}, fb, { idToken: j.id_token, refreshToken: j.refresh_token, exp: Date.now() + (Number(j.expires_in || 3600) - 60) * 1000 }));
    return fb.idToken;
  }

  const DOC = () => "https://firestore.googleapis.com/v1/projects/" + cfg().projectId + "/databases/(default)/documents";
  const fval = v => typeof v === "number" ? { integerValue: String(Math.round(v)) } : { stringValue: String(v == null ? "" : v) };

  // Store one message. Fire-and-forget; never blocks or breaks the chat.
  async function logMessage(m) {
    try {
      if (!enabled() || !consented() || !fb) return;
      const tok = await freshToken();
      const fields = {
        uid: fval(fb.uid), name: fval(m.name || ""), email: fval(fb.email || m.email || ""),
        photo: fval(m.photo || ""), role: fval(m.role || "user"), text: fval(String(m.text || "").slice(0, 7000)),
        agent: fval(m.agent || ""), agentName: fval(m.agentName || ""), ts: { integerValue: String(m.ts || Date.now()) }
      };
      await fetch(DOC() + "/messages?key=" + encodeURIComponent(cfg().apiKey), {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok },
        body: JSON.stringify({ fields })
      });
      // keep a light "users" record so the owner has the roster even before the first message scroll
      fetch(DOC() + "/users?documentId=" + encodeURIComponent(fb.uid) + "&key=" + encodeURIComponent(cfg().apiKey), {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok },
        body: JSON.stringify({ fields: { name: fval(m.name || ""), email: fval(fb.email || ""), photo: fval(m.photo || ""), lastSeen: { integerValue: String(Date.now()) } } })
      }).catch(() => {});
    } catch (e) { /* offline / not linked — ignore, chat continues */ }
  }

  // v2.20.4: "I'm online" — updates lastSeen on the user's record (upsert) every minute while the app is open
  async function heartbeat(name, photo) {
    try {
      if (!enabled() || !consented() || !fb) return;
      const tok = await freshToken();
      const q = ["lastSeen", "email"].concat(name ? ["name"] : []).concat(photo ? ["photo"] : []).map(f => "updateMask.fieldPaths=" + f).join("&");
      const fields = { lastSeen: { integerValue: String(Date.now()) }, email: fval(fb.email || "") };
      if (name) fields.name = fval(name); if (photo) fields.photo = fval(photo);
      await fetch(DOC() + "/users/" + encodeURIComponent(fb.uid) + "?" + q + "&key=" + encodeURIComponent(cfg().apiKey), {
        method: "PATCH", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok }, body: JSON.stringify({ fields })
      });
    } catch (e) {}
  }
  // owner: when was each user last seen (best effort — falls back to their last message)
  async function fetchSeen(tok) {
    try {
      const r = await fetch("https://firestore.googleapis.com/v1/projects/" + cfg().projectId + "/databases/(default)/documents:runQuery?key=" + encodeURIComponent(cfg().apiKey), {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok },
        body: JSON.stringify({ structuredQuery: { from: [{ collectionId: "users" }], limit: 500 } })
      });
      const j = await r.json().catch(() => ([]));
      const out = {};
      (Array.isArray(j) ? j : []).forEach(x => { if (!x.document) return; const id = x.document.name.split("/").pop(); const f = x.document.fields || {};
        out[id] = Number(f.lastSeen && f.lastSeen.integerValue) || 0; });
      return out;
    } catch (e) { return {}; }
  }

  function parseDoc(d) {
    const f = d.fields || {}; const g = k => f[k] ? (f[k].stringValue != null ? f[k].stringValue : f[k].integerValue) : "";
    return { uid: g("uid"), name: g("name"), email: g("email"), photo: g("photo"), role: g("role"), text: g("text"), agentName: g("agentName"), ts: Number(g("ts")) || 0 };
  }

  // Owner: pull the most recent messages across everyone, newest first.
  async function fetchAll(limit) {
    if (!enabled()) throw new Error("no-config");
    const tok = await freshToken();
    const r = await fetch("https://firestore.googleapis.com/v1/projects/" + cfg().projectId + "/databases/(default)/documents:runQuery?key=" + encodeURIComponent(cfg().apiKey), {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok },
      body: JSON.stringify({ structuredQuery: { from: [{ collectionId: "messages" }], orderBy: [{ field: { fieldPath: "ts" }, direction: "DESCENDING" }], limit: limit || 300 } })
    });
    const j = await r.json().catch(() => ([]));
    if (!r.ok) throw new Error((j.error && j.error.message) || ("HTTP " + r.status));
    const rows = (Array.isArray(j) ? j : []).filter(x => x.document).map(x => parseDoc(x.document));
    // group by user
    const byUser = {};
    for (const m of rows) { const k = m.uid || m.email || "?"; (byUser[k] = byUser[k] || { uid: k, name: m.name, email: m.email, photo: m.photo, msgs: [] }).msgs.push(m); if (m.name) byUser[k].name = byUser[k].name || m.name; }
    const seen = await fetchSeen(tok);
    Object.values(byUser).forEach(u => { u.lastSeen = Math.max(seen[u.uid] || 0, (u.msgs[0] && u.msgs[0].ts) || 0); });
    return { rows, users: Object.values(byUser) };
  }

  // v2.14: the free-trial start date lives on the user's account (trials/{uid}), so reinstalling doesn't restart it.
  // Returns the earliest known start (cloud or local). Best effort — on any error returns the local value.
  async function trialStart(localStart) {
    try {
      if (!enabled() || !fb) return localStart;
      const tok = await freshToken();
      const url = DOC() + "/trials/" + encodeURIComponent(fb.uid) + "?key=" + encodeURIComponent(cfg().apiKey);
      const r = await fetch(url, { headers: { Authorization: "Bearer " + tok } });
      if (r.ok) {
        const j = await r.json().catch(() => ({}));
        const t = Number(j.fields && j.fields.start && j.fields.start.integerValue) || 0;
        if (t && t <= localStart) return t;
      } else if (r.status !== 404) return localStart;
      await fetch(url, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok },
        body: JSON.stringify({ fields: { start: { integerValue: String(Math.round(localStart)) }, email: { stringValue: fb.email || "" } } }) });
      return localStart;
    } catch (e) { return localStart; }
  }

  window.DACloud = {
    LS, cfg, setCfg, enabled, consented, setConsent, linkGoogle, logMessage, fetchAll, trialStart, freshToken, heartbeat,
    linked: () => !!fb, who: () => fb, clear: () => { saveFb(null); try { localStorage.removeItem(LS.fb); } catch (e) {} }
  };
})();
