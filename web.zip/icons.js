/* DA.ai v2.40 — one set of thin line icons (like Claude's), each with its own shape.
   Emojis in the app's menus, settings and windows are swapped for these icons. Messages in the chat are left as they are. */
(function () {
  "use strict";
  // 24×24, drawn with lines only (stroke = current text color, no fill)
  var P = {
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.3-4.3"/>',
    chat: '<path d="M4 5.5h16v11H9l-5 4z"/>',
    newchat: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    check: '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M8 12.5l3 3 5-6"/>',
    money: '<rect x="3" y="6" width="18" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.6"/><path d="M6.5 9.5v.01M17.5 14.5v.01"/>',
    wallet: '<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3"/><rect x="3.5" y="7.5" width="17" height="12" rx="2.5"/><path d="M16 13.5h.01"/>',
    note: '<path d="M6 3.5h9l4 4V20a.5.5 0 0 1-.5.5h-12A.5.5 0 0 1 6 20z"/><path d="M15 3.5v4h4M9 12h6M9 15.5h6"/>',
    puzzle: '<path d="M10 4h4v2.5a1.5 1.5 0 1 0 3 0V4h3v6h-2.5a1.5 1.5 0 1 0 0 3H20v7h-6v-2.5a1.5 1.5 0 1 0-3 0V20H4v-6h2.5a1.5 1.5 0 1 0 0-3H4V4z"/>',
    palette: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.7-.9 1.4-1.8-.4-1.2.3-2.2 1.6-2.2h1.8A3.7 3.7 0 0 0 20.5 13 9 9 0 0 0 12 3.5z"/><circle cx="7.8" cy="11" r="1"/><circle cx="10.5" cy="7.5" r="1"/><circle cx="15" cy="8" r="1"/>',
    file: '<path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/>',
    folder: '<path d="M3.5 7A1.5 1.5 0 0 1 5 5.5h4.5l2 2.5H19A1.5 1.5 0 0 1 20.5 9.5V18a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l2-1.5-2-3.5-2.4 1a7.6 7.6 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A7.6 7.6 0 0 0 7 6.5l-2.4-1-2 3.5 2 1.5a7.6 7.6 0 0 0 0 3l-2 1.5 2 3.5 2.4-1a7.6 7.6 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a7.6 7.6 0 0 0 2.6-1.5l2.4 1 2-3.5z"/>',
    crown: '<path d="M3.5 8l4 3.5L12 5l4.5 6.5 4-3.5-1.5 10.5h-14z"/><path d="M5.5 21h13"/>',
    brain: '<path d="M9.5 4A2.5 2.5 0 0 0 7 6.5 2.7 2.7 0 0 0 4.5 9.2c0 .8.3 1.4.8 1.9a2.8 2.8 0 0 0 .2 4.4A2.6 2.6 0 0 0 9.5 19a1.9 1.9 0 0 0 2.5 1V5.2A1.9 1.9 0 0 0 9.5 4zM14.5 4A2.5 2.5 0 0 1 17 6.5a2.7 2.7 0 0 1 2.5 2.7c0 .8-.3 1.4-.8 1.9a2.8 2.8 0 0 1-.2 4.4A2.6 2.6 0 0 1 14.5 19a1.9 1.9 0 0 1-2.5 1"/>',
    bolt: '<path d="M13 2.5L4.5 13.5H11l-1 8 8.5-11H12z"/>',
    phone: '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M11 18h2"/>',
    call: '<path d="M5 4h3.5l2 5-2.5 1.5a11 11 0 0 0 5.5 5.5L15 13.5l5 2V19a1.5 1.5 0 0 1-1.5 1.5A16.5 16.5 0 0 1 3.5 5.5 1.5 1.5 0 0 1 5 4z"/>',
    music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5v3.5"/>',
    speaker: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    camera: '<path d="M4 8h3l2-2.5h6L17 8h3a1 1 0 0 1 1 1v9.5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
    image: '<rect x="3.5" y="3.5" width="17" height="17" rx="3.5"/><circle cx="9" cy="9" r="1.6"/><path d="M20.5 15l-5-5L5 20.5"/>',
    clip: '<path d="M20 11.5l-7.8 7.8a5 5 0 0 1-7-7L13 4.5a3.3 3.3 0 0 1 4.7 4.7L10 17a1.7 1.7 0 0 1-2.4-2.4l7-7"/>',
    receipt: '<path d="M6 3h12v18l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 21z"/><path d="M9 8h6M9 11.5h6M9 15h3"/>',
    scan: '<path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16M7 12h10"/>',
    books: '<path d="M4 19.5V5a1.5 1.5 0 0 1 1.5-1.5H9V19.5"/><path d="M9 19.5V5.5h4.5V19.5M14.5 6.5l3.5-1 3 13.5-3.5 1z"/><path d="M3 20.5h11"/>',
    history: '<path d="M3.5 12a8.5 8.5 0 1 0 2.5-6L3.5 8.5"/><path d="M3.5 4v4.5H8M12 7.5V12l3 2"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>',
    plug: '<path d="M9 3v5M15 3v5M6.5 8h11v3a5.5 5.5 0 0 1-11 0zM12 16.5V21"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.6 3.5 5.6 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.6-3.5-8.5S9.5 6.1 12 3.5z"/>',
    share: '<path d="M12 3.5v12M7.5 8L12 3.5 16.5 8"/><path d="M5 13v5.5A2 2 0 0 0 7 20.5h10a2 2 0 0 0 2-2V13"/>',
    download: '<path d="M12 3.5v12M7.5 11L12 15.5 16.5 11"/><path d="M4.5 19.5h15"/>',
    copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="2.5"/><path d="M15.5 8.5V5.5a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    trash: '<path d="M4.5 6.5h15M9.5 6.5V4h5v2.5M6.5 6.5l1 13.5h9l1-13.5M10 10.5v6M14 10.5v6"/>',
    pin: '<path d="M9 3.5h6l-1 5 3.5 3.5h-11L10 8.5z"/><path d="M12 12v8.5"/>',
    home: '<path d="M3.5 11L12 4l8.5 7"/><path d="M6 9.5V20h12V9.5M10 20v-5.5h4V20"/>',
    list: '<path d="M8.5 6.5h12M8.5 12h12M8.5 17.5h12M4 6.5h.01M4 12h.01M4 17.5h.01"/>',
    chart: '<path d="M4 20.5h16"/><path d="M6.5 17V11M11 17V6.5M15.5 17v-8M20 17v-4"/>',
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 9.5h18M7 15h3"/>',
    cloud: '<path d="M7 18.5a4.5 4.5 0 0 1-.6-9 6 6 0 0 1 11.4 1.5A3.8 3.8 0 0 1 17.5 18.5z"/>',
    bubble: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 9.5a3.5 3.5 0 0 1 3.5-3"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3"/>',
    gift: '<rect x="3.5" y="8" width="17" height="4" rx="1"/><path d="M5 12v8.5h14V12M12 8v12.5M12 8C10 4 6.5 4.5 7.5 6.5S12 8 12 8zm0 0c2-4 5.5-3.5 4.5-1.5S12 8 12 8z"/>',
    vibrate: '<rect x="8" y="4" width="8" height="16" rx="2"/><path d="M4.5 9v6M19.5 9v6M2 10.5v3M22 10.5v3"/>',
    tools: '<path d="M14.5 6.5a4 4 0 0 0 4.8 5.2l-8.6 8.6a2 2 0 0 1-2.8-2.8l8.6-8.6a4 4 0 0 0-2-5.2z"/><path d="M4 4l4 4M3.5 7.5l3.5-3.5"/>',
    laptop: '<rect x="4.5" y="5" width="15" height="10.5" rx="1.5"/><path d="M2.5 19h19"/>',
    code: '<path d="M8.5 7.5L4 12l4.5 4.5M15.5 7.5L20 12l-4.5 4.5M13.5 5l-3 14"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 16.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.8l-5.2 2.8 1-5.8-4.3-4.1 5.9-.8z"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.2 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',
    bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/>',
    mail: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
    users: '<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 5a3.5 3.5 0 0 1 0 7M18.5 14.5a6.5 6.5 0 0 1 3 5.5"/>',
    handshake: '<path d="M3 11.5l3.5-4 4 1.5 2.5-1.5 3 1 5 3.5"/><path d="M7 14l3 3 1.5-1 1.5 1.5 1.5-1 1.5 1 3-3.5M6.5 7.5L3 11.5l4 2.5"/>',
    briefcase: '<rect x="3" y="7" width="18" height="12.5" rx="2.5"/><path d="M9 7V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v2M3 12.5h18"/>',
    pen: '<path d="M15.5 4.5l4 4L9 19l-5 1 1-5z"/><path d="M13.5 6.5l4 4"/>',
    megaphone: '<path d="M4 10v4h3l9 4.5V5.5L7 10z"/><path d="M7 14l1.5 5.5h2.5L10 14.5M19 9.5a3 3 0 0 1 0 5"/>',
    cart: '<circle cx="9.5" cy="19.5" r="1.3"/><circle cx="17.5" cy="19.5" r="1.3"/><path d="M3 4h2.5l2.3 11h11.4l1.8-8H6.6"/>',
    truck: '<path d="M2.5 6.5h11v9.5h-11zM13.5 10h4l3 3v3h-7z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    car: '<path d="M4 16.5v-4l2-5h12l2 5v4z"/><circle cx="7.5" cy="16.5" r="1.8"/><circle cx="16.5" cy="16.5" r="1.8"/><path d="M4 12.5h16"/>',
    health: '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.2 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/><path d="M7.5 12h2.5l1.2-2.2 1.8 4.2 1.2-2h2.3"/>',
    pill: '<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-35 12 12)"/><path d="M9.5 9.3l5 3.5" transform="rotate(0)"/>',
    food: '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M16.5 3c-2 1-3 3.5-3 6.5h3V21"/>',
    graduation: '<path d="M2.5 9L12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11v4.5c0 1.5 2.5 3 5.5 3s5.5-1.5 5.5-3V11M21.5 9v5"/>',
    scale: '<path d="M12 4v16M6 20h12M5 7.5h14M7.5 7.5L4.5 14a3 3 0 0 0 6 0zM16.5 7.5L13.5 14a3 3 0 0 0 6 0z"/>',
    building: '<rect x="5" y="3.5" width="14" height="17" rx="1.5"/><path d="M9 7.5h.01M15 7.5h.01M9 11h.01M15 11h.01M9 14.5h.01M15 14.5h.01M10.5 20.5v-3h3v3"/>',
    rocket: '<path d="M12 15l-3-3c1-4 4-7.5 9.5-8.5C17.5 9 14 12 12 15z"/><path d="M9 12l-3.5.5-2 2.5 4 .5M12 15l-.5 3.5-2.5 2-.5-4M15 8.5h.01"/>',
    shield: '<path d="M12 3l7.5 3v5.5c0 4.5-3.2 8.2-7.5 9.5-4.3-1.3-7.5-5-7.5-9.5V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    moon: '<path d="M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
    contrast: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z"/>',
    text: '<path d="M5 7V5h14v2M12 5v14M9 19h6"/>',
    refresh: '<path d="M20 11.5a8 8 0 0 0-14.5-4.2L3.5 9.5"/><path d="M3.5 4.5v5h5M4 12.5a8 8 0 0 0 14.5 4.2l2-2.2"/><path d="M20.5 19.5v-5h-5"/>',
    save: '<path d="M5 3.5h11.5l4 4V19a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19V5A1.5 1.5 0 0 1 5 3.5z"/><path d="M7.5 3.5v5h8v-5M7.5 20.5v-6.5h9v6.5"/>',
    broom: '<path d="M14 3.5l-3.5 8"/><path d="M7 11.5h7.5l2 9h-11.5z"/><path d="M9.5 15v5.5M13 15v5.5"/>',
    send: '<path d="M4 12l16-8-6 16-2.5-6.5z"/><path d="M11.5 13.5L20 4"/>',
    rocketup: '<path d="M12 19.5V5M6.5 10.5L12 5l5.5 5.5"/>',
    whatsapp: '<path d="M5 19.5l1-3.5a7.8 7.8 0 1 1 3 3z"/><path d="M9.5 8.5c0 3.5 2.5 6 6 6l1-1.5-2-1-1 .8a4 4 0 0 1-2.2-2.2l.8-1-1-2z"/>',
    telegram: '<path d="M21 4.5L3 11.5l5.5 2 2 6 3-4 5 3.5z"/><path d="M8.5 13.5L18 7"/>',
    sticker: '<path d="M14.5 20.5H6A2.5 2.5 0 0 1 3.5 18V6A2.5 2.5 0 0 1 6 3.5h12A2.5 2.5 0 0 1 20.5 6v8.5z"/><path d="M20.5 14.5h-4a2 2 0 0 0-2 2v4M8.5 10h.01M15 10h.01M9 14.5c1.5 1.2 3.5 1.2 5 0"/>',
    up: '<path d="M7 10v10H4.5A1.5 1.5 0 0 1 3 18.5v-7A1.5 1.5 0 0 1 4.5 10zm0 0l4-7a2.2 2.2 0 0 1 3.4 2.3L13.6 9H19a2 2 0 0 1 2 2.3l-1.2 7a2 2 0 0 1-2 1.7H7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.5h.01"/>',
    warn: '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    qr: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2.5v2.5M20 14v6h-3.5M14 20h.01"/>',
    square: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
    cube: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
    diamond: '<path d="M12 3l9 9-9 9-9-9z"/>',
    film: '<rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="M7.5 5v14M16.5 5v14M3.5 9.5h4M3.5 14.5h4M16.5 9.5h4M16.5 14.5h4"/>',
    tiger: '<path d="M5 6l2.5 2M19 6l-2.5 2"/><path d="M12 20c-4.5 0-7.5-3.2-7.5-7.5 0-3.5 3.2-6 7.5-6s7.5 2.5 7.5 6c0 4.3-3 7.5-7.5 7.5z"/><path d="M9 11.5h.01M15 11.5h.01M10.5 15.5L12 17l1.5-1.5M12 7v2.5M8 8.5l1 2M16 8.5l-1 2"/>'
  };

  // emoji → icon (the emoji's meaning decides the shape)
  var E = {
    "🎵": "music", "🎶": "music", "🎼": "music", "🎹": "music", "🎸": "music",
    "🧰": "tools", "😕": "info", "💛": "heart", "🎂": "gift", "👎": "x", "🐞": "warn", "🎉": "sparkle", "🔘": "check", "🔇": "speaker", "⛔": "x",
    "🔴": "warn", "🔓": "lock", "🚨": "warn", "🎫": "card", "❗": "warn", "🔕": "bell", "🛟": "shield", "↔": null, "🟩": null, "🟥": null,
    "🔍": "search", "🔎": "search", "💬": "chat", "🗨️": "chat", "✏️": "newchat", "📝": "note", "🗒️": "note", "✅": "check", "☑️": "check", "✔️": "check",
    "💰": "money", "💵": "money", "💸": "money", "🪙": "money", "₪": null, "👛": "wallet", "🏦": "building", "💳": "card",
    "🧩": "puzzle", "🎨": "palette", "📄": "file", "📃": "file", "📑": "file", "📁": "folder", "📂": "folder", "🗂️": "folder",
    "⚙️": "gear", "⚙": "gear", "🛠️": "tools", "🛠": "tools", "🔧": "tools", "🔨": "tools",
    "👑": "crown", "🧠": "brain", "⚡": "bolt", "📱": "phone", "📲": "phone", "📞": "call", "☎️": "call", "🎙️": "mic", "🎤": "mic",
    "🔊": "speaker", "🔈": "speaker", "📢": "megaphone", "📣": "megaphone", "📷": "camera", "📸": "camera", "🖼️": "image", "🖼": "image", "🌄": "image",
    "📎": "clip", "🧾": "receipt", "📚": "books", "📖": "books", "🕓": "history", "⏱️": "clock", "⏰": "clock", "🕒": "clock", "🔗": "link", "🔌": "plug",
    "🌐": "globe", "🌍": "globe", "📤": "share", "⬇️": "download", "📥": "download", "📋": "copy", "🗑️": "trash", "🗑": "trash",
    "📌": "pin", "📍": "pin", "🏠": "home", "🏡": "home", "📊": "chart", "📈": "chart", "📉": "chart", "☁️": "cloud", "🫧": "bubble",
    "🔒": "lock", "🔐": "lock", "🔑": "lock", "🎁": "gift", "📳": "vibrate", "🧑‍💻": "laptop", "👨‍💻": "laptop", "💻": "laptop", "🖥️": "laptop",
    "➕": "plus", "✨": "sparkle", "🌟": "star", "⭐": "star", "❤️": "heart", "💖": "heart", "🔔": "bell", "📅": "calendar", "🗓️": "calendar", "📆": "calendar",
    "✉️": "mail", "📧": "mail", "📨": "mail", "👤": "user", "🙋": "user", "👥": "users", "👨‍👩‍👧": "users", "🤝": "handshake", "💼": "briefcase",
    "✍️": "pen", "🖊️": "pen", "🛒": "cart", "🛍️": "cart", "🚚": "truck", "🚗": "car", "🏎️": "car", "🩺": "health", "💊": "pill", "🍽️": "food", "🍳": "food",
    "🎓": "graduation", "⚖️": "scale", "🏢": "building", "🚀": "rocket", "🛡️": "shield", "👁️": "eye", "👀": "eye", "🌙": "moon", "🌗": "contrast", "☀️": "sun", "🌞": "sun",
    "🔤": "text", "🔠": "text", "🔄": "refresh", "🔃": "refresh", "💾": "save", "🧹": "broom", "📩": "send", "✈️": "telegram", "💚": "whatsapp", "🟢": null,
    "😀": "sticker", "😊": "sticker", "🙂": "sticker", "🤖": "sparkle", "👍": "up", "❌": "x", "✖️": "x", "ℹ️": "info", "⚠️": "warn", "🐯": "tiger", "🐅": "tiger",
    "◻️": "square", "◻": "square", "⬜": "square", "🧸": "cube", "🧊": "cube", "🔷": "diamond", "🔶": "diamond", "💎": "diamond", "🎬": "film", "🎥": "film", "📹": "film", "✕": "x", "☰": "list", "✓": null, "✔": null, "❯": null, "★": "star", "☆": "star", "♥": "heart", "☺": "sticker", "☑": "check", "✉": "mail", "✂️": "tools", "✂": "tools", "⏳": "clock", "⌛": "clock", "♻️": "refresh", "↩️": null, "▶️": null, "⏹️": null, "⏸️": null, "⬆️": null, "➡️": null, "⬅️": null,
    "📐": "puzzle", "🧮": "chart", "🔥": "bolt", "🎯": "check", "🧭": "globe", "🗣️": "mic", "🎧": "speaker", "🧑‍💼": "briefcase", "👨‍💼": "briefcase"
  };

  function svg(name) { return '<svg class="dai" viewBox="0 0 24 24" aria-hidden="true">' + P[name] + "</svg>"; }
  var RX = /(\p{Extended_Pictographic}|[☀-➿])(️|‍(\p{Extended_Pictographic}|[☀-➿])️?|\p{Emoji_Modifier})*/gu;
  // only the app's own frame — never the chat, inputs or what the user wrote
  var ROOTS = "header.top, #side, #drawer, #plusSheet, #moreMenu, #outlineSheet, #filesSheet, #ownerSheet, #imgSheet, #sheet, #composer .row, #tabs, .mic2, #modalCard, #subModal, #toast, .toast, #pills, #glStarBar, #msgs .who, .gl-header, #plusBody, #famBody";
  var SKIP = "input, textarea, select, [contenteditable], #msgs .bub, #msgs .acts, .bub, video, svg, script, style, .noIcon, #olList span, .daiE, .daiT, #famList, #sbList, #gfList, #mpList, #daTrBox, #fbStars, #sbAdm, .skinName";

  function iconize(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        if (!n.nodeValue || !RX.test(n.nodeValue)) { RX.lastIndex = 0; return NodeFilter.FILTER_REJECT; }
        RX.lastIndex = 0;
        var p = n.parentElement; if (!p || p.closest(SKIP)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var list = []; while (walker.nextNode()) list.push(walker.currentNode);
    list.forEach(function (n) {
      var html = "", last = 0, t = n.nodeValue, m, any = false;
      RX.lastIndex = 0;
      while ((m = RX.exec(t))) {
        var key = E[m[0]] || E[m[0].replace(/️/g, "")] || E[m[0] + "️"];
        html += esc(t.slice(last, m.index));
        if (key) { html += svg(key); any = true; }
        else if (key === null) { html += esc(m[0]); }
        else { html += '<span class="daiE">' + esc(m[0]) + "</span>"; any = true; } // no shape yet: shown without colors
        last = m.index + m[0].length;
      }
      if (!any) return;
      html += esc(t.slice(last));
      var span = document.createElement("span"); span.className = "daiT"; span.innerHTML = html.replace(/(<\/svg>)\s+/g, "$1 ");
      n.parentNode.replaceChild(span, n);
    });
  }
  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  var busy = false;
  function run() {
    if (busy) return; busy = true;
    try { document.querySelectorAll(ROOTS).forEach(iconize); } catch (e) {}
    busy = false;
  }
  var t = 0;
  function soon() { clearTimeout(t); t = setTimeout(run, 60); }
  window.DAIcons = { svg: svg, names: Object.keys(P), run: run };
  window.addEventListener("load", function () {
    var st = document.createElement("style");
    st.textContent = ".dai{width:1.2em;height:1.2em;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round;vertical-align:-.24em;flex:none;display:inline-block}" +
      ".daiE{filter:grayscale(1) contrast(1.15);opacity:.85}" +
      "#side .sNav button span .dai,#side .sConv i .dai{width:22px;height:22px}#plusSheet .pTile .dai{width:24px;height:24px}";
    document.head.appendChild(st);
    run();
    new MutationObserver(function (ms) { if (busy) return; for (var i = 0; i < ms.length; i++) if (ms[i].addedNodes.length || ms[i].type === "characterData") { soon(); return; } })
      .observe(document.body, { childList: true, subtree: true, characterData: true });
  });
})();
