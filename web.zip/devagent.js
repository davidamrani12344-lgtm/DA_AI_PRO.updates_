/* DA.ai Developer Agent v1.0 — lets David's agents change the app itself, the way Claude does:
   read and edit the code in GitHub, check the builds, and publish an update to every installed app.
   Everything goes through the DA.ai server (Cloudflare Worker), which holds the GitHub token and only
   lets the owner in. Anything that cannot be undone (publishing to all users) asks David first. */
(function () {
  "use strict";
  // Set once the server is deployed (e.g. "https://da-ai-server.<name>.workers.dev"). Empty = off.
  var SERVER = "https://da-ai-server.davidamrani12344.workers.dev";
  var REPO = "davidamrani12344-lgtm/DA_AI_PRO";
  var OWNER_EMAIL = "davidamrani12344@gmail.com";

  // v2.17: older versions could save the old built-in Gemini key on the phone as if it were the user's own.
  // That key is being retired, so drop it (recognised by its start only — the key itself is not in the code).
  (function () {
    function old(k) { return typeof k === "string" && k.indexOf("AQ.Ab8RN6Ihf7") === 0; }
    try {
      ["daai_gemini_key", "gemini_api_key"].forEach(function (n) { if (old(localStorage.getItem(n))) localStorage.removeItem(n); });
      var c = JSON.parse(localStorage.getItem("da_sticker_cfg") || "null");
      if (c && old(c.apiKey)) { c.apiKey = ""; localStorage.setItem("da_sticker_cfg", JSON.stringify(c)); }
      if (old(localStorage.getItem("daai_ella_key") || "") || (localStorage.getItem("daai_ella_key") || "").indexOf("ctk_gilV") === 0) localStorage.removeItem("daai_ella_key");
    } catch (e) {}
  })();

  function server() {
    try { var o = (localStorage.getItem("daai_server") || "").trim(); if (o) return o.replace(/\/+$/, ""); } catch (e) {}
    return SERVER.replace(/\/+$/, "");
  }
  function email() {
    try { var st = (typeof S !== "undefined" && S) ? S : JSON.parse(localStorage.getItem("daai_state") || "null"); return String((st && st.profile && st.profile.email) || "").toLowerCase(); } catch (e) { return ""; }
  }
  // owner = David's Google account, confirmed by the server (see checkOwner in index.html)
  function isOwner() { try { return email() === OWNER_EMAIL && localStorage.getItem("daai_owner_ok") === OWNER_EMAIL; } catch (e) { return false; } }

  async function token() {
    if (!(window.DACloud && DACloud.freshToken)) throw new Error("צריך להתחבר עם Google");
    try { return await DACloud.freshToken(); } catch (e) { throw new Error("צריך להתחבר עם Google (חשבון DA.ai)"); }
  }
  // fetch through the DA.ai server with the signed-in user's token
  async function call(path, opts, retried) {
    var base = server();
    if (!base) throw new Error("שרת DA.ai עוד לא מחובר");
    opts = opts || {};
    var headers = Object.assign({ "Authorization": "Bearer " + await token() }, opts.headers || {});
    try { var code = localStorage.getItem("daai_plan_code"); if (code) headers["X-DA-Plan"] = code; } catch (e) {}
    var os = ownerSess(); if (os) headers["X-DA-Owner"] = os;
    var r = await fetch(base + path, Object.assign({}, opts, { headers: headers }));
    // v2.44: owner controls are locked with David's password — ask for it once, then try again
    if (r.status === 401 && !retried && isOwner()) {
      var j = null; try { j = await r.clone().json(); } catch (e) {}
      if (j && j.error && j.error.status === "OWNER_LOCKED") { try { localStorage.removeItem("daai_owner_sess"); } catch (e) {} if (await ownerUnlock()) return call(path, opts, true); }
    }
    return r;
  }

  /* ---------- v2.44: owner password (the server keeps only an encrypted fingerprint) ---------- */
  function ownerSess() { try { var x = JSON.parse(localStorage.getItem("daai_owner_sess") || "null"); return x && x.exp > Date.now() ? x.t : ""; } catch (e) { return ""; } }
  var unlocking = null;
  function ownerUnlock() {
    if (unlocking) return unlocking;
    unlocking = new Promise(function (done) {
      (async function () {
        var st = {}; try { st = await (await call("/owner/lock", {}, true)).json(); } catch (e) {}
        var first = st && st.set === false;
        var w = document.createElement("div");
        w.id = "daOwnerLock";
        w.style.cssText = "position:fixed;inset:0;z-index:2147483600;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;direction:rtl;font-family:inherit";
        w.innerHTML = '<div style="background:#141414;border:1px solid #333;border-radius:18px;padding:22px;width:min(340px,88vw);color:#eee;text-align:center">' +
          '<div style="font-size:18px;font-weight:600;margin-bottom:6px">🔒 נעילת בעלים</div>' +
          '<div style="font-size:13px;color:#aaa;margin-bottom:14px">' + (first ? "בחר סיסמת בעלים (6 תווים לפחות). רק אתה תוכל לפתוח את הגדרות הבעלים, הסוכנים והשרת." : "הקלד את סיסמת הבעלים כדי לפתוח ל-12 שעות.") + '</div>' +
          '<input id="daOP1" type="password" autocomplete="off" placeholder="סיסמה" style="width:100%;box-sizing:border-box;padding:12px;border-radius:12px;border:1px solid #444;background:#0b0b0b;color:#fff;font-size:16px;margin-bottom:8px">' +
          (first ? '<input id="daOP2" type="password" autocomplete="off" placeholder="שוב, לאישור" style="width:100%;box-sizing:border-box;padding:12px;border-radius:12px;border:1px solid #444;background:#0b0b0b;color:#fff;font-size:16px;margin-bottom:8px">' : '') +
          '<div id="daOPm" style="min-height:18px;font-size:13px;color:#f87171;margin-bottom:8px"></div>' +
          '<div style="display:flex;gap:8px"><button id="daOPok" style="flex:1;padding:12px;border-radius:12px;border:0;background:#fff;color:#000;font-size:15px;font-weight:600">' + (first ? "שמור" : "פתח") + '</button>' +
          '<button id="daOPx" style="flex:1;padding:12px;border-radius:12px;border:1px solid #444;background:transparent;color:#ddd;font-size:15px">ביטול</button></div></div>';
        document.body.appendChild(w);
        var $ = function (id) { return w.querySelector("#" + id); };
        setTimeout(function () { $("daOP1").focus(); }, 50);
        function end(v) { w.remove(); unlocking = null; done(v); }
        $("daOPx").onclick = function () { end(false); };
        $("daOP1").onkeydown = function (e) { if (e.key === "Enter") $("daOPok").click(); };
        $("daOPok").onclick = async function () {
          var p1 = $("daOP1").value, m = $("daOPm");
          if (p1.length < 6) { m.textContent = "לפחות 6 תווים"; return; }
          if (first && $("daOP2").value !== p1) { m.textContent = "הסיסמאות לא זהות"; return; }
          this.disabled = true; m.style.color = "#aaa"; m.textContent = "בודק…";
          try {
            var H = { "Content-Type": "application/json" };
            if (first) { var a = await call("/owner/pin", { method: "POST", headers: H, body: JSON.stringify({ pin: p1 }) }, true); if (!a.ok) throw await a.json(); }
            var r = await call("/owner/unlock", { method: "POST", headers: H, body: JSON.stringify({ pin: p1 }) }, true), j = await r.json();
            if (!r.ok) throw j;
            localStorage.setItem("daai_owner_sess", JSON.stringify({ t: j.token, exp: Date.now() + (j.hours || 12) * 3600000 - 60000 }));
            end(true);
          } catch (e) { this.disabled = false; m.style.color = "#f87171"; m.textContent = (e && e.error && e.error.message) || "לא הצלחתי — בדוק חיבור"; }
        };
      })();
    });
    return unlocking;
  }
  async function ownerLockNow() { try { await call("/owner/lockout", { method: "POST" }, true); } catch (e) {} try { localStorage.removeItem("daai_owner_sess"); } catch (e) {} }

  /* ---------- GitHub helpers ---------- */
  function b64encode(str) {
    var bytes = new TextEncoder().encode(str), bin = "";
    for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }
  function cleanPath(p) { return String(p || "").replace(/^\/+/, "").split("/").map(encodeURIComponent).join("/"); }
  async function gh(method, path, body, accept) {
    var r = await call("/gh/repos/" + REPO + path, {
      method: method,
      headers: Object.assign({ "Content-Type": "application/json" }, accept ? { "Accept": accept } : {}),
      body: body ? JSON.stringify(body) : undefined
    });
    if (!r.ok) {
      var t = await r.text().catch(function () { return ""; });
      var m = t; try { m = JSON.parse(t).message || (JSON.parse(t).error && JSON.parse(t).error.message) || t; } catch (e) {}
      var err = new Error("GitHub " + r.status + ": " + String(m).slice(0, 300)); err.status = r.status; throw err;
    }
    return accept && accept.indexOf("raw") >= 0 ? r.text() : r.json();
  }
  async function readFile(path) {
    var meta = await gh("GET", "/contents/" + cleanPath(path) + "?ref=main");
    if (Array.isArray(meta)) throw new Error(path + " היא תיקייה");
    var text = await gh("GET", "/contents/" + cleanPath(path) + "?ref=main", null, "application/vnd.github.raw+json");
    return { text: text, sha: meta.sha };
  }
  async function writeFile(path, text, sha, message) {
    var body = { message: message || ("DA.ai agent: update " + path), content: b64encode(text), branch: "main" };
    if (sha) body.sha = sha;
    var r = await gh("PUT", "/contents/" + cleanPath(path), body);
    return { ok: true, commit: r.commit && r.commit.sha && r.commit.sha.slice(0, 7) };
  }
  function log(ok, t) { try { if (typeof logAct === "function") logAct(ok, t); } catch (e) {} }

  /* v2.25: check code before it is saved, so a typo can't break the app */
  function checkCode(path, text) {
    var p = String(path || "").toLowerCase();
    try {
      if (/\.json$/.test(p)) { JSON.parse(text); return null; }
      if (/\.js$/.test(p)) { if (/^\s*(import|export)\s/m.test(text)) return null; new Function(text); return null; }
      if (/\.html?$/.test(p)) {
        var re = /<script(?![^>]*\bsrc=)([^>]*)>([\s\S]*?)<\/script>/gi, m, n = 0;
        while ((m = re.exec(text))) {
          n++;
          if (/type\s*=\s*["']?(module|application\/json|application\/ld\+json|text\/template)/i.test(m[1])) continue;
          try { new Function(m[2]); }
          catch (e) { var line = text.slice(0, m.index).split("\n").length; return "שגיאת קוד בסקריפט מספר " + n + " (מתחיל בשורה " + line + "): " + e.message; }
        }
        return null;
      }
      if (/\.(java|kt)$/.test(p)) {
        var depth = 0; for (var i = 0; i < text.length; i++) { var c = text[i]; if (c === "{") depth++; else if (c === "}") depth--; if (depth < 0) break; }
        return depth === 0 ? null : "הסוגריים המסולסלים { } לא מאוזנים בקובץ";
      }
    } catch (e) { return "שגיאת קוד: " + e.message; }
    return null;
  }
  // areas where a change goes live at once (the server, the build robots): David approves each one
  function sensitivePath(p) { return /^(worker\/|\.github\/|app\/build\.gradle|app\/src\/main\/androidmanifest\.xml)/i.test(String(p || "")); }

  var NOTES = "PROJECT_NOTES.md";

  // "Are you sure?" for actions that cannot be undone
  function approve(text) {
    return new Promise(function (res) { setTimeout(function () { res(window.confirm(text)); }, 50); });
  }

  var TOOLS = [
    { name: "dev_list_files", ownerOnly: true,
      description: "Developer agent: list the files of the DA.ai app source code in GitHub. path: folder (\"\" = root, \"web\", \"app/src/main/java/pro/da_ai/agent\", \"worker/src\").",
      inputSchema: { type: "object", properties: { path: { type: "string" } } },
      async execute(a) {
        var r = await gh("GET", "/contents/" + cleanPath(a.path || "") + "?ref=main");
        if (!Array.isArray(r)) return { file: r.path, size: r.size };
        log(true, "קורא תיקייה: " + (a.path || "/"));
        return r.map(function (f) { return { path: f.path, type: f.type, size: f.size }; });
      } },
    { name: "dev_search_code", ownerOnly: true,
      description: "Developer agent: find text in one source file. Returns matching line numbers with the line. Use before editing to find the exact place. Main app UI and logic: web/index.html.",
      inputSchema: { type: "object", properties: { path: { type: "string" }, text: { type: "string" } }, required: ["path", "text"] },
      async execute(a) {
        var f = await readFile(a.path), q = String(a.text).toLowerCase(), out = [];
        f.text.split("\n").forEach(function (l, i) { if (out.length < 60 && l.toLowerCase().indexOf(q) >= 0) out.push({ line: i + 1, text: l.slice(0, 300) }); });
        log(true, "מחפש בקוד: " + a.text);
        return { path: a.path, matches: out };
      } },
    { name: "dev_read_code", ownerOnly: true,
      description: "Developer agent: read lines from a source file (max 400 lines per call). from/to are 1-based line numbers.",
      inputSchema: { type: "object", properties: { path: { type: "string" }, from: { type: "number" }, to: { type: "number" } }, required: ["path"] },
      async execute(a) {
        var lines = (await readFile(a.path)).text.split("\n");
        var from = Math.max(1, Number(a.from) || 1), to = Math.min(lines.length, Number(a.to) || from + 199, from + 399);
        log(true, "קורא קוד: " + a.path + " " + from + "-" + to);
        return { path: a.path, totalLines: lines.length, from: from, to: to,
          code: lines.slice(from - 1, to).map(function (l, i) { return (from + i) + ": " + l; }).join("\n") };
      } },
    { name: "dev_edit_code", ownerOnly: true,
      description: "Developer agent: change the app source code in GitHub. Replaces old_text (must appear exactly once in the file, copied exactly without line numbers) with new_text and saves it as a commit. This starts a new APK/AAB build but does NOT reach users until dev_publish_update. Read the code first.",
      inputSchema: { type: "object", properties: { path: { type: "string" }, old_text: { type: "string" }, new_text: { type: "string" }, message: { type: "string" } }, required: ["path", "old_text", "new_text"] },
      async execute(a) {
        var f = await readFile(a.path), parts = f.text.split(String(a.old_text));
        if (parts.length === 1) throw new Error("הטקסט לא נמצא בקובץ — קרא שוב את הקוד והעתק בדיוק");
        if (parts.length > 2) throw new Error("הטקסט מופיע " + (parts.length - 1) + " פעמים — הוסף עוד שורות כדי שיהיה ייחודי");
        var next = parts.join(String(a.new_text)), bad = checkCode(a.path, next);
        if (bad) { log(false, "השינוי לא נשמר — " + bad); return { ok: false, saved: false, error: bad + " — תקן את new_text ונסה שוב" }; }
        if (sensitivePath(a.path) && !(await approve("סוכן המפתח רוצה לשנות את " + a.path + "\n(שינוי כאן משפיע מיד על השרת או על הבנייה)\n\nלאשר?"))) return { ok: false, reason: "David did not approve" };
        var r = await writeFile(a.path, next, f.sha, a.message);
        log(true, "שונה בקוד: " + a.path + " (" + r.commit + ")");
        return r;
      } },
    { name: "dev_create_file", ownerOnly: true,
      description: "Developer agent: create a new source file in GitHub (fails if it already exists).",
      inputSchema: { type: "object", properties: { path: { type: "string" }, content: { type: "string" }, message: { type: "string" } }, required: ["path", "content"] },
      async execute(a) {
        try { await readFile(a.path); throw new Error("הקובץ כבר קיים — השתמש ב-dev_edit_code"); } catch (e) { if (e.status !== 404) throw e; }
        var bad = checkCode(a.path, String(a.content));
        if (bad) return { ok: false, saved: false, error: bad };
        if (sensitivePath(a.path) && !(await approve("סוכן המפתח רוצה ליצור את " + a.path + "\n\nלאשר?"))) return { ok: false, reason: "David did not approve" };
        var r = await writeFile(a.path, String(a.content), null, a.message);
        log(true, "נוצר קובץ: " + a.path);
        return r;
      } },
    { name: "dev_build_status", ownerOnly: true,
      description: "Developer agent: see the latest GitHub builds (APK, Google Play AAB, server, app updates) and whether they passed.",
      inputSchema: { type: "object", properties: {} },
      async execute() {
        var r = await gh("GET", "/actions/runs?per_page=8");
        log(true, "בודק בניות");
        return (r.workflow_runs || []).map(function (w) {
          return { name: w.name, status: w.status, result: w.conclusion, commit: (w.head_commit && w.head_commit.message || "").split("\n")[0].slice(0, 100), started: w.created_at, url: w.html_url };
        });
      } },
    { name: "dev_publish_update", ownerOnly: true,
      description: "Developer agent: send the current web code to EVERY installed app as a live update. Cannot be undone, so David is asked to approve first. Only after the edits are done.",
      inputSchema: { type: "object", properties: { notes: { type: "string", description: "What changed, in Hebrew, shown to users" } }, required: ["notes"] },
      async execute(a) {
        var notes = String(a.notes || "שיפורים ותיקונים").slice(0, 200);
        if (!(await approve("לשלוח עדכון לכל המשתמשים?\n\n" + notes))) { log(false, "העדכון לא נשלח — לא אושר"); return { ok: false, reason: "David did not approve" }; }
        await gh("POST", "/actions/workflows/publish-web.yml/dispatches", { ref: "main", inputs: { notes: notes } });
        log(true, "העדכון נשלח לפרסום");
        return { ok: true, note: "publishing started; check dev_build_status in ~1 minute" };
      } }
  ];

  TOOLS.push(
    { name: "dev_check_code", ownerOnly: true,
      description: "Developer agent: check a source file in GitHub for code errors (JS / HTML scripts / JSON / Java braces) without changing it. Edits are checked automatically too.",
      inputSchema: { type: "object", properties: { path: { type: "string" } }, required: ["path"] },
      async execute(a) { var f = await readFile(a.path), bad = checkCode(a.path, f.text); log(!bad, bad ? "נמצאה שגיאה ב-" + a.path : "הקוד תקין: " + a.path); return bad ? { ok: false, error: bad } : { ok: true, note: "no syntax errors found" }; } },
    { name: "dev_project_notes", ownerOnly: true,
      description: "Developer agent: READ FIRST before any change. The project's memory: how DA.ai is built, where things are, decisions, rules and past problems (file PROJECT_NOTES.md).",
      inputSchema: { type: "object", properties: {} },
      async execute() { try { var f = await readFile(NOTES); log(true, "קורא את זיכרון הפרויקט"); return { notes: f.text.slice(-30000) }; } catch (e) { if (e.status === 404) return { notes: "(empty)" }; throw e; } } },
    { name: "dev_add_note", ownerOnly: true,
      description: "Developer agent: remember something for next time in the project memory (a decision, where something is, a problem and its fix). One short line.",
      inputSchema: { type: "object", properties: { note: { type: "string" } }, required: ["note"] },
      async execute(a) {
        var f = null; try { f = await readFile(NOTES); } catch (e) { if (e.status !== 404) throw e; }
        var line = "- " + new Date().toISOString().slice(0, 10) + ": " + String(a.note).replace(/\s+/g, " ").slice(0, 400);
        var r = await writeFile(NOTES, (f ? f.text.replace(/\s*$/, "\n") : "# DA.ai project notes\n\n") + line + "\n", f && f.sha, "DA.ai agent: project note");
        log(true, "נשמר בזיכרון הפרויקט"); return r;
      } },
    { name: "dev_latest_apk", ownerOnly: true,
      description: "Developer agent: the download link of the newest APK that was built, to give David so he can install and check a change.",
      inputSchema: { type: "object", properties: {} },
      async execute() {
        var r = await gh("GET", "/releases?per_page=1"), x = r && r[0];
        if (!x) return { error: "no builds yet" };
        var apk = (x.assets || []).filter(function (s) { return /\.apk$/.test(s.name); })[0];
        log(true, "קישור לגרסה: " + x.name);
        return { version: x.name, built: x.created_at, apk: apk && apk.browser_download_url };
      } }
  );

  window.DA_DEV_TOOLS = TOOLS;
  window.DAServer = { url: server, call: call, isOwner: isOwner, ownerUnlock: ownerUnlock, ownerLock: ownerLockNow, ownerOpen: function () { return !!ownerSess(); } };
})();
