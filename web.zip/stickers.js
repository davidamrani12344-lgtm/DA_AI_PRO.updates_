/* DA.ai Sticker Studio v2.0
 * Text → AI sticker · Photo → sticker (Gemini cartoonify / AI cut / colour cut / circle / square)
 * Non-destructive editor · persistent packs (IndexedDB) · WhatsApp-compliant output
 * WhatsApp rules: 512×512 WebP ≤100KB, tray 96×96 PNG ≤50KB, 3–30 stickers per pack
 * Android bridge: window.DAStickers (StickerBridge.java)
 */
(function () {
  'use strict';
  const VERSION = '2.0.0';
  const $ = (id) => document.getElementById(id);
  const MAX = 30, MIN = 3, LIMIT = 100 * 1024, TRAY_LIMIT = 50 * 1024;
  const POL_REFERRER = 'da-ai-pro';

  const STYLES = [
    { id: '3d', label: '✨ תלת-ממד', s: 'cute 3D cartoon render, Pixar-like, soft glossy lighting' },
    { id: 'anime', label: '🌸 אנימה', s: 'kawaii chibi anime, clean cel shading' },
    { id: 'vector', label: '🎯 וקטור', s: 'flat vector illustration, bold outlines, bold colors' },
    { id: 'doodle', label: '✏️ דודל', s: 'hand drawn doodle, thick marker lines' },
    { id: 'pixel', label: '👾 פיקסל', s: 'pixel art, 16-bit, crisp pixels' },
    { id: 'clay', label: '🧸 פלסטלינה', s: 'claymation, plasticine, handmade texture' },
    { id: 'neon', label: '🌃 ניאון', s: 'neon glow cyberpunk style, vibrant glowing edges' },
    { id: 'real', label: '📸 ריאליסטי', s: 'realistic photo, studio lighting' }
  ];
  const COLORS = {
    gold: ['#fff1c1', '#f0d488', '#b8892c'],
    fire: ['#ffe14d', '#ff9a1a', '#ff3d1a'],
    white: ['#ffffff', '#ffffff', '#e9e9e9'],
    neon: ['#b8fff4', '#33e6ff', '#7a5cff'],
    pink: ['#ffd1ec', '#ff6fb5', '#d6247f'],
    green: ['#e2ffd1', '#5fe37a', '#159a48']
  };
  const DEF = { shape: 'cut', cut: 'color', tol: 60, caption: '', capPos: 'bottom', capColor: 'gold', capSize: 1, outline: 9, shadow: true };
  const EMOJI_HINTS = [
    [/חתול|חתולה|cat/i, '🐱'], [/כלב|כלבה|dog/i, '🐶'], [/אוהב|אהבה|לב|love/i, '❤️'], [/בוקר/i, '☀️'],
    [/לילה|ערב/i, '🌙'], [/יום הולדת|מזל טוב/i, '🎂'], [/צוחק|צחוק|חחח|מצחיק/i, '😂'], [/כועס|עצבני/i, '😠'],
    [/עצוב|בוכה/i, '😢'], [/מלך|כתר|מלכה/i, '👑'], [/אש|בוער|🔥/i, '🔥'], [/כסף|עשיר/i, '💰'],
    [/תודה/i, '🙏'], [/יאללה|קדימה/i, '💪'], [/שלום|היי|הי/i, '👋'], [/אוכל|רעב|פיצה/i, '🍕'], [/ישן|עייף/i, '😴']
  ];

  const S = { packs: [], cur: null, style: STYLES[0], multi: false, attached: null, cfg: {}, busy: false };

  // ================= small utils =================
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = (p) => (p || '') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const kb = (n) => Math.round(n / 1024) + 'KB';
  const bytesOf = (dataUrl) => Math.floor((dataUrl.length - dataUrl.indexOf(',') - 1) * 3 / 4);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const haptic = (ms) => { try { window.AndroidApp && window.AndroidApp.vibrate && window.AndroidApp.vibrate(ms || 18); } catch (e) { } };
  const bridge = () => window.DAStickers || null;
  let toastT;
  function toast(t) { const el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2600); }

  function fetchT(url, opt, ms) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms || 45000);
    return fetch(url, Object.assign({}, opt, { signal: ctl.signal }))
      .catch((e) => { throw new Error(e.name === 'AbortError' ? 'השרת לא ענה בזמן. נסה שוב.' : (navigator.onLine ? 'בעיית רשת: ' + e.message : 'אין חיבור לאינטרנט')); })
      .finally(() => clearTimeout(t));
  }
  function withTimeout(p, ms, msg) { return Promise.race([p, new Promise((_, bad) => setTimeout(() => bad(new Error(msg || 'timeout')), ms))]); }

  // ================= storage =================
  const DB = (function () {
    let dbp = null;
    function open() {
      if (dbp) return dbp;
      dbp = new Promise((ok, bad) => {
        if (!window.indexedDB) return bad(new Error('no indexedDB'));
        const r = indexedDB.open('da_stickers', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('packs', { keyPath: 'id' });
        r.onsuccess = () => ok(r.result); r.onerror = () => bad(r.error);
      });
      dbp.catch(() => { dbp = null; });
      return dbp;
    }
    async function run(mode, fn) {
      const db = await open();
      return new Promise((ok, bad) => {
        const t = db.transaction('packs', mode); let res;
        const rq = fn(t.objectStore('packs')); if (rq) rq.onsuccess = () => { res = rq.result; };
        t.oncomplete = () => ok(res); t.onerror = () => bad(t.error); t.onabort = () => bad(t.error);
      });
    }
    return {
      all: () => run('readonly', (s) => s.getAll()),
      put: (p) => run('readwrite', (s) => s.put(p)),
      del: (id) => run('readwrite', (s) => s.delete(id))
    };
  })();
  let warnedStore = false;
  async function persist(pack) {
    try { await DB.put(JSON.parse(JSON.stringify(pack))); }
    catch (e) { if (!warnedStore) { warnedStore = true; toast('⚠️ לא הצלחתי לשמור בזיכרון המכשיר'); } }
  }

  function newPack(name) {
    return { id: uid('da_'), name: name || 'המדבקות של DA', publisher: 'DA.ai', version: 1, sentVersion: 0, dirty: false, trayId: null, stickers: [], created: Date.now() };
  }
  async function loadPacks() {
    try { S.packs = (await DB.all()) || []; } catch (e) { S.packs = []; }
    S.packs.sort((a, b) => a.created - b.created);
    if (!S.packs.length) { const p = newPack(); S.packs.push(p); persist(p); }
    const last = localStorage.getItem('da_sticker_cur');
    S.cur = S.packs.find((p) => p.id === last) || S.packs[S.packs.length - 1];
  }
  function touch(pack) { pack.dirty = true; persist(pack); }

  // ================= settings =================
  function loadCfg() {
    let c = {}; try { c = JSON.parse(localStorage.getItem('da_sticker_cfg') || '{}'); } catch (e) { }
    S.cfg = {
      apiKey: c.apiKey || localStorage.getItem('daai_gemini_key') || localStorage.getItem('gemini_api_key') || '',
      proxyUrl: c.proxyUrl || '', model: (c.model && c.model !== 'gemini-2.5-flash-image') ? c.model : '', polKey: c.polKey || '',
      aiCut: c.aiCut !== false, style: c.style || '3d'
    };
    S.style = STYLES.find((s) => s.id === S.cfg.style) || STYLES[0];
  }
  function saveCfg() { localStorage.setItem('da_sticker_cfg', JSON.stringify(S.cfg)); }
  // always read the newest saved key (the main app may save it after the studio loaded)
  function curKey() {
    try {
      var c = JSON.parse(localStorage.getItem('da_sticker_cfg') || '{}');
      var k = (c.apiKey || localStorage.getItem('daai_gemini_key') || localStorage.getItem('gemini_api_key') || '').trim();
      if (k) return k;
      return (typeof window.DEFAULT_GEMINI_KEY === 'string' ? window.DEFAULT_GEMINI_KEY : (window.__DA_DEF_GEM || '')).trim();
    } catch (e) { return ''; }
  }
  const hasGemini = () => !!(curKey() || S.cfg.proxyUrl);

  function openCfg() {
    $('apiKey').value = S.cfg.apiKey; $('proxyUrl').value = S.cfg.proxyUrl; $('model').value = S.cfg.model;
    $('polKey').value = S.cfg.polKey; $('aiCut').checked = S.cfg.aiCut; show('cfg');
  }
  $('btnCfg').onclick = openCfg;
  $('btnSaveCfg').onclick = () => {
    Object.assign(S.cfg, {
      apiKey: $('apiKey').value.trim(), proxyUrl: $('proxyUrl').value.trim(),
      model: $('model').value.trim(), polKey: $('polKey').value.trim(), aiCut: $('aiCut').checked
    });
    saveCfg(); hide('cfg');
    bot(hasGemini() ? '✅ Gemini מחובר! עכשיו אפשר גם להפוך תמונות לקרטון/אנימה.' : '✅ נשמר. עובד במצב חינמי.');
  };
  $('btnTestKey').onclick = async () => {
    const key = $('apiKey').value.trim(); if (!key) return toast('הדבק קודם מפתח');
    const b = $('btnTestKey'); b.disabled = true; b.textContent = '…';
    try {
      const r = await fetchT('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1&key=' + encodeURIComponent(key), {}, 15000);
      toast(r.ok ? '✅ המפתח תקין' : '❌ המפתח לא תקין (' + r.status + ')');
    } catch (e) { toast('❌ ' + e.message); }
    b.disabled = false; b.textContent = 'בדיקה';
  };

  // ================= sheets =================
  function show(id) { $(id).hidden = false; haptic(10); }
  function hide(id) { $(id).hidden = true; }
  document.querySelectorAll('[data-close]').forEach((b) => (b.onclick = () => hide(b.dataset.close)));
  document.querySelectorAll('.sheet').forEach((sh) => sh.addEventListener('click', (e) => { if (e.target === sh) hide(sh.id); }));

  $('btnBack').onclick = () => { if (history.length > 1 && document.referrer) history.back(); else location.href = 'index.html'; };

  // ================= chat UI =================
  const chat = $('chat');
  const scroll = () => requestAnimationFrame(() => { chat.scrollTop = chat.scrollHeight; });
  function bubble(cls, html) { const d = document.createElement('div'); d.className = 'm ' + cls; d.innerHTML = html; chat.appendChild(d); scroll(); return d; }
  function bot(text) { return bubble('a', esc(text)); }
  function typing(label) {
    const d = bubble('a', '<span class="typing"><span class="dots"><span></span><span></span><span></span></span><small></small></span>');
    d.set = (t) => { d.querySelector('small').textContent = t || ''; }; d.set(label); return d;
  }

  // style chips
  STYLES.forEach((st) => {
    const b = document.createElement('button'); b.textContent = st.label; b.setAttribute('role', 'radio');
    if (st === S.style) b.classList.add('on');
    b.onclick = () => {
      document.querySelectorAll('#styles button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on'); S.style = st; S.cfg.style = st.id; saveCfg(); haptic(8);
    };
    $('styles').appendChild(b);
  });

  const msg = $('msg');
  msg.addEventListener('input', () => { msg.style.height = 'auto'; msg.style.height = Math.min(msg.scrollHeight, 120) + 'px'; });
  msg.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  $('btnSend').onclick = send;
  $('btnMulti').onclick = () => {
    S.multi = !S.multi; $('btnMulti').setAttribute('aria-pressed', String(S.multi));
    toast(S.multi ? '×4 פעיל: 4 גרסאות לכל בקשה' : '×4 כבוי'); haptic(8);
  };

  $('btnGallery').onclick = () => $('gallery').click();
  $('gallery').onchange = async (e) => {
    const f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    try {
      S.attached = await shrink(await blobToDataUrl(f), 1024);
      $('attachImg').src = S.attached; $('attach').hidden = false; msg.focus();
    } catch (err) { bot('😕 ' + err.message); }
  };
  $('attachX').onclick = () => { S.attached = null; $('attach').hidden = true; };

  function updateNet() { const on = navigator.onLine; $('netState').textContent = on ? 'מחובר' : 'אופליין'; $('netState').classList.toggle('off', !on); }
  window.addEventListener('online', updateNet); window.addEventListener('offline', updateNet);

  // ================= understanding the request =================
  function parse(text) {
    let caption = '';
    const q = text.match(/["“”„״]([^"“”„״]{1,40})["“”„״]/) || text.match(/(?:^|\s)'([^']{1,40})'(?=$|[\s.,!?])/);
    const w = text.match(/(?:שכתוב עליה|שכתוב עליו|שכתוב|עם הכיתוב|עם הטקסט|עם המילים|שאומרת|שאומר|כיתוב|טקסט)[:\s]+(.{1,40})$/);
    if (q) caption = q[1].trim(); else if (w) caption = w[1].trim();
    let shape = 'auto';
    if (/עיגול|עגול/.test(text)) shape = 'circle';
    else if (/ריבוע|מרובע/.test(text)) shape = 'rounded';
    else if (/בלי חיתוך|כמו שזה|מקורי/.test(text)) shape = 'none';
    else if (/חתוך|חיתוך|בלי רקע|תוריד רקע|הסר רקע|הורד רקע/.test(text)) shape = 'cut';
    let emoji = (text.match(/\p{Extended_Pictographic}/gu) || []).slice(0, 3).join('');
    if (!emoji) { const h = EMOJI_HINTS.find(([re]) => re.test(text)); emoji = h ? h[1] : '😀'; }
    let desc = text;
    if (q) desc = desc.replace(q[0], ' ');
    desc = desc.replace(/(?:שכתוב עליה|שכתוב עליו|שכתוב|עם הכיתוב|עם הטקסט|עם המילים|שאומרת|שאומר|כיתוב|טקסט)[:\s]*.*$/, ' ')
      .replace(/\p{Extended_Pictographic}/gu, ' ').replace(/\s+/g, ' ').trim();
    return { caption, shape, emoji, desc: desc || text };
  }

  // ================= send =================
  async function send() {
    if (S.busy) return;
    const text = msg.value.trim(); const photo = S.attached;
    if (!text && !photo) { msg.focus(); return; }
    haptic(15);
    bubble('u', (photo ? `<img class="photo" src="${photo}" alt="">` : '') + esc(text || 'תעשה מזה מדבקה'));
    msg.value = ''; msg.style.height = 'auto'; S.attached = null; $('attach').hidden = true;
    const req = Object.assign({ text, photo, style: S.style.s }, parse(text));
    setBusy(true);
    try {
      if (!photo && S.multi) await makeVariants(req);
      else await make(req);
    } finally { setBusy(false); }
  }
  function setBusy(b) { S.busy = b; $('btnSend').disabled = b; $('btnSend').classList.toggle('busy', b); }

  /** Creates one sticker. Returns creation {src, p, out, bytes, emoji} */
  async function make(req, seed) {
    const t = typing('חושב…');
    try {
      let src, p = Object.assign({}, DEF, { caption: req.caption }), note; S.lastGemWhy = '';
      if (req.photo && hasGemini() && imageAllowed()) {
        try {
          t.set('🎨 מצייר עם Gemini…');
          src = await geminiImage(photoPrompt(req), req.photo); p.shape = 'cut'; p.cut = 'color';
          note = 'הנה, הפכתי את התמונה למדבקה 🎨';
        } catch (e) {
          src = req.photo; Object.assign(p, await photoShape(req, t));
          note = 'Gemini לא הצליח (' + e.message + '), אז עשיתי מדבקה מהתמונה המקורית.';
        }
      } else if (req.photo) {
        src = req.photo; Object.assign(p, await photoShape(req, t));
        note = 'הנה המדבקה מהתמונה שלך 👇 אפשר לערוך צורה, כיתוב ומסגרת.';
      } else {
        t.set('✨ יוצר תמונה…');
        src = await textToImage(req, seed); p.shape = 'cut'; p.cut = 'color';
        note = S.lastGemWhy ? 'הנה המדבקה ✨ (צוירה בשרת הגיבוי, כי Gemini: ' + S.lastGemWhy + ')' : 'הנה המדבקה שלך ✨';
      }
      if (req.shape !== 'auto') p.shape = req.shape;
      t.set('✂️ מעבד…');
      const r = await renderSticker(src, p);
      t.remove();
      const cr = { id: uid('s_'), src, p, out: r.out, bytes: r.bytes, emoji: req.emoji };
      showSticker(cr, note, req);
      return cr;
    } catch (e) {
      t.remove();
      if (!req.photo && (req.caption || req.text)) {
        const cr = await textCreation(req.caption || req.desc.slice(0, 22), req.emoji);
        showSticker(cr, 'לא היה חיבור ל-AI (' + e.message + '), אז הכנתי מדבקת טקסט:', req);
        return cr;
      }
      bot('😕 ' + e.message);
      return null;
    }
  }

  async function photoShape(req, t) {
    if (req.shape !== 'auto') return { shape: req.shape, cut: S.cfg.aiCut ? 'ai' : 'color' };
    if (await plainBackground(req.photo)) return { shape: 'cut', cut: 'color' };
    if (S.cfg.aiCut) { t && t.set('🧠 חיתוך AI…'); return { shape: 'cut', cut: 'ai' }; }
    return { shape: 'circle' };
  }

  async function makeVariants(req) {
    const d = bubble('a', esc('4 גרסאות בשבילך – בחר את מה שאהבת 👇') + '<div class="variants"></div>');
    const grid = d.querySelector('.variants');
    const tiles = [0, 1, 2, 3].map(() => { const el = document.createElement('div'); el.className = 'tile loading'; el.innerHTML = '<div class="spin"></div>'; grid.appendChild(el); return el; });
    scroll();
    const one = async (i) => {
      const el = tiles[i];
      try {
        const src = await textToImage(req, Math.floor(Math.random() * 1e9));
        const p = Object.assign({}, DEF, { caption: req.caption, shape: req.shape === 'auto' ? 'cut' : req.shape });
        const r = await renderSticker(src, p);
        const cr = { id: uid('s_'), src, p, out: r.out, bytes: r.bytes, emoji: req.emoji };
        el.className = 'tile'; el.innerHTML = `<img src="${cr.out}" alt=""><div class="tb"><button class="ok">➕</button><button>✏️</button></div>`;
        const [add, edit] = el.querySelectorAll('button');
        add.onclick = () => { if (addToPack(cr)) { add.textContent = '✓'; add.disabled = true; } };
        edit.onclick = () => openEditor(cr, { onApply: () => { el.querySelector('img').src = cr.out; } });
      } catch (e) { el.className = 'tile fail'; el.textContent = 'לא הצליח 😕'; }
    };
    // 2 at a time — kinder to the free AI
    await Promise.all([one(0).then(() => one(2)), one(1).then(() => one(3))]);
    scroll();
  }

  function showSticker(cr, note, req) {
    const d = bubble('a', esc(note) + '<div class="stk-wrap"><img alt="מדבקה"><span class="badge"></span></div><div class="acts"></div>');
    const img = d.querySelector('img'), badge = d.querySelector('.badge');
    const paint = () => { img.src = cr.out; badge.textContent = `512×512 · ${kb(cr.bytes)} ${cr.bytes <= LIMIT ? '✓' : '⚠️'}`; badge.classList.toggle('bad', cr.bytes > LIMIT); };
    paint();
    const acts = d.querySelector('.acts');
    const btn = (label, fn, cls) => { const b = document.createElement('button'); b.textContent = label; if (cls) b.className = cls; b.onclick = fn; acts.appendChild(b); return b; };
    const addB = btn('➕ לחבילה', () => { if (addToPack(cr)) { addB.textContent = '✓ נוסף'; addB.classList.add('done'); addB.disabled = true; } }, 'ok');
    btn('✏️ עריכה', () => openEditor(cr, { onApply: paint }));
    btn('🔄 עוד גרסה', () => { if (!S.busy) { setBusy(true); make(req, Math.floor(Math.random() * 1e9)).finally(() => setBusy(false)); } });
    btn('💾', () => saveOne(cr));
    haptic(25);
  }

  // ================= AI =================
  function stickerPrompt(desc, st) {
    return `Create a single die-cut sticker illustration. The user's request (may be in Hebrew — follow it exactly): "${desc}". ` +
      `Show EVERY element the request mentions (all characters, objects and actions), together as one compact centered group, fully visible, nothing cropped. ` +
      `Style: ${st}. Expressive, thick clean shapes, vivid colors, smooth clean silhouette. ` +
      `Background: flat solid pure white (#FFFFFF) only — no sky, no clouds, no splashes, no paint strokes, no scenery, no ground, no shadows on the background. ` +
      `No text, no letters, no border, no frame, no watermark.`;
  }
  function photoPrompt(req) {
    return `Turn the main subject of this photo into a sticker. Keep the person's/subject's recognizable features and expression. ` +
      `Style: ${req.style}. ${req.desc ? 'User request: ' + req.desc + '. ' : ''}` +
      `One centered subject, isolated on a plain pure white background, no text, no letters, no border, no watermark.`;
  }

  async function textToImage(req, seed) {
    const desc = req.desc || req.text;
    let gemWhy = '';
    if (hasGemini()) {
      if (imageAllowed()) {
        try { return await geminiImage(stickerPrompt(desc, req.style)); } catch (e) { gemWhy = e.message; console.warn('Gemini image failed:', e); }
      } else gemWhy = 'הגעת למכסת המדבקות היומית במסלול שלך. לשדרוג — 💎 במסך הראשי';
    }
    S.lastGemWhy = gemWhy;
    const en = await toEnglish(desc);
    const prompt = encodeURIComponent(stickerPrompt(en, req.style));
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const attempt = async (model) => {
      const sd = seed != null ? seed : Math.floor(Math.random() * 1e9);
      const qs = `width=768&height=768&nologo=true&model=${model}&seed=${sd}&referrer=${POL_REFERRER}`;
      const urls = [];
      if (S.cfg.polKey) urls.push(`https://gen.pollinations.ai/image/${prompt}?${qs}&key=${encodeURIComponent(S.cfg.polKey)}`);
      urls.push(`https://image.pollinations.ai/prompt/${prompt}?${qs}`);
      let last;
      for (const u of urls) {
        try {
          const res = await fetchT(u, {}, 70000);
          if (!res.ok) { last = new Error('busy ' + res.status); continue; }
          const blob = await res.blob();
          if (!/^image\//.test(blob.type) && blob.size < 2000) { last = new Error('bad reply'); continue; }
          return await blobToDataUrl(blob);
        } catch (e) { last = e; }
      }
      throw last || new Error('fail');
    };
    // try a few times with backoff, and two models — the free service is often briefly overloaded
    const models = ['flux', 'turbo', 'flux'];
    let last;
    for (let i = 0; i < models.length; i++) {
      try { return await attempt(models[i]); }
      catch (e) { last = e; if (i < models.length - 1) await sleep(1500 * (i + 1)); }
    }
    throw new Error(gemWhy ? 'Gemini: ' + gemWhy : 'שרת התמונות עמוס כרגע. נסה שוב עוד רגע 🙏');
  }

  // Hebrew → English so the free image model understands
  const trCache = new Map();
  async function toEnglish(text) {
    if (!/[֐-׿]/.test(text)) return text;
    if (trCache.has(text)) return trCache.get(text);
    const ask = 'Translate this Hebrew image description to short natural English. Reply with the translation only, no quotes: ' + text;
    let out = '';
    if (hasGemini()) {
      try {
        const data = await geminiText(ask);
        out = ((data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) || []).map((p) => p.text || '').join('').trim();
      } catch (e) { }
    }
    if (!out) {
      try {
        const r = await fetchT('https://text.pollinations.ai/' + encodeURIComponent(ask) + '?referrer=' + POL_REFERRER, {}, 12000);
        if (r.ok) out = (await r.text()).trim();
      } catch (e) { }
    }
    if (!out || out.length > 400 || /[֐-׿]/.test(out)) out = text;
    trCache.set(text, out); return out;
  }

  // v2.14: find the image models this key can really use (names change over time), best first
  async function imageModels() {
    const out = [];
    const add = (m) => { m = String(m || '').replace(/^models\//, '').trim(); if (m && !out.includes(m)) out.push(m); };
    add(S.cfg.model); add(S.goodModel || localStorage.getItem('da_sticker_img_model'));
    if (!S.listed && !S.cfg.proxyUrl) {
      S.listed = [];
      try {
        const r = await fetchT('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000&key=' + encodeURIComponent(curKey()), {}, 15000);
        const j = await r.json();
        S.listed = (j.models || []).filter((m) => /image/i.test(m.name) && /gemini/i.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent'))
          .map((m) => m.name.replace(/^models\//, ''))
          .sort((a, b) => (/flash/.test(b) - /flash/.test(a)) || (/preview/.test(a) - /preview/.test(b)) || b.localeCompare(a, 'en', { numeric: true }));
      } catch (e) { }
    }
    (S.listed || []).slice(0, 4).forEach(add);
    ['gemini-3.1-flash-image', 'gemini-3-flash-image', 'gemini-2.5-flash-image'].forEach(add);
    return out.slice(0, 5);
  }
  async function geminiText(ask) {
    let last;
    for (const m of ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-2.5-flash']) {
      try { return await geminiCall(m, { contents: [{ parts: [{ text: ask }] }] }, 15000); } catch (e) { last = e; }
    }
    throw last;
  }
  // v2.14: images cost money on the shared key, so they count against the user's plan (plan.js)
  function imageAllowed() {
    try { return !window.DAPlan || window.DAPlan.useImage(); } catch (e) { return true; }
  }

  async function geminiCall(model, body, ms) {
    const key = curKey(), proxy = S.cfg.proxyUrl;
    const url = proxy ? proxy.replace(/\/$/, '') + `/v1beta/models/${model}:generateContent`
      : `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
    const headers = { 'Content-Type': 'application/json' };
    const res = await fetchT(url, { method: 'POST', headers, body: JSON.stringify(body) }, ms || 90000);
    if (!res.ok) {
      let m = ''; try { m = ((await res.json()).error || {}).message || ''; } catch (e) { }
      throw new Error('Gemini ' + res.status + (res.status === 429 ? ' – עברת את המכסה, נסה עוד דקה' : res.status === 400 || res.status === 403 ? ' – בדוק את המפתח' : '') + (m && res.status !== 400 && res.status !== 403 ? ' – ' + m.slice(0, 80) : ''));
    }
    return res.json();
  }
  async function geminiImage(prompt, photo) {
    const parts = [{ text: prompt }];
    if (photo) {
      const i = photo.indexOf(','); const mime = (photo.slice(0, i).match(/data:(.*?);/) || [])[1] || 'image/jpeg';
      parts.push({ inlineData: { mimeType: mime, data: photo.slice(i + 1) } });
    }
    const body = { contents: [{ parts }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } };
    const models = await imageModels();
    let data = null, p = null, last = null;
    for (const m of models) {
      try {
        data = await geminiCall(m, body);
        p = ((data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) || []).find((x) => x.inlineData || x.inline_data);
        if (p) { if (S.goodModel !== m) { S.goodModel = m; try { localStorage.setItem('da_sticker_img_model', m); } catch (e) { } } break; }
        last = new Error('לא הוחזרה תמונה (' + m + ')');
      } catch (e) { last = e; if (/429|מכסה/.test(e.message) && !/limit: 0|free_tier/i.test(e.message)) break; }
    }
    if (!p) throw last || new Error('Gemini לא החזיר תמונה');
    const d = p.inlineData || p.inline_data;
    try { window.DAUsage && window.DAUsage.add('img', 1); } catch (e) {}
    return `data:${d.mimeType || d.mime_type || 'image/png'};base64,${d.data}`;
  }

  // ================= image helpers =================
  function blobToDataUrl(b) { return new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => bad(new Error('קריאת הקובץ נכשלה')); r.readAsDataURL(b); }); }
  function loadImg(src) { return new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => bad(new Error('לא הצלחתי לפתוח את התמונה')); i.src = src; }); }
  function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h == null ? w : h; return c; }
  const ctx2d = (c) => c.getContext('2d', { willReadFrequently: true });
  async function shrink(src, max) {
    const img = await loadImg(src);
    const s = Math.min(1, max / Math.max(img.width, img.height));
    const c = canvas(Math.round(img.width * s), Math.round(img.height * s));
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.9);
  }
  async function plainBackground(src) {
    const img = await loadImg(src);
    const c = canvas(64), x = ctx2d(c); x.drawImage(img, 0, 0, 64, 64);
    const p = x.getImageData(0, 0, 64, 64).data, edge = [];
    for (let i = 0; i < 64; i++) edge.push(i, 63 * 64 + i, i * 64, i * 64 + 63);
    const avg = [0, 1, 2].map((k) => edge.reduce((a, i) => a + p[i * 4 + k], 0) / edge.length);
    const dev = edge.reduce((a, i) => a + Math.abs(p[i * 4] - avg[0]) + Math.abs(p[i * 4 + 1] - avg[1]) + Math.abs(p[i * 4 + 2] - avg[2]), 0) / edge.length;
    return dev < 40;
  }
  function fitCanvas(img, max) {
    const s = Math.min(max / img.width, max / img.height, 2);
    const c = canvas(Math.max(1, Math.round(img.width * s)), Math.max(1, Math.round(img.height * s)));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return c;
  }
  function shapeCrop(img, size, shape) {
    const c = canvas(size), x = c.getContext('2d'), side = Math.min(img.width, img.height);
    const sx = (img.width - side) / 2, sy = (img.height - side) / 2;
    x.beginPath();
    if (shape === 'circle') x.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
    else if (x.roundRect) x.roundRect(0, 0, size, size, size * 0.12); else x.rect(0, 0, size, size);
    x.clip(); x.drawImage(img, sx, sy, side, side, 0, 0, size, size); return c;
  }

  /** Colour-based background removal: flood fill from the borders + island cleanup + soft edges */
  function colorCut(cv, tol) {
    const w = cv.width, h = cv.height, cx = ctx2d(cv), im = cx.getImageData(0, 0, w, h), p = im.data, N = w * h;
    const rs = [], gs = [], bs = [];
    const sample = (i) => { if (p[i * 4 + 3] > 200) { rs.push(p[i * 4]); gs.push(p[i * 4 + 1]); bs.push(p[i * 4 + 2]); } };
    for (let x = 0; x < w; x += 2) { sample(x); sample((h - 1) * w + x); }
    for (let y = 0; y < h; y += 2) { sample(y * w); sample(y * w + w - 1); }
    const med = (a) => { if (!a.length) return 255; a.sort((m, n) => m - n); return a[a.length >> 1]; };
    const bg = [med(rs), med(gs), med(bs)];
    const dist = (i) => Math.abs(p[i * 4] - bg[0]) + Math.abs(p[i * 4 + 1] - bg[1]) + Math.abs(p[i * 4 + 2] - bg[2]);
    const isBg = (i) => p[i * 4 + 3] < 16 || dist(i) < tol;
    const mask = new Uint8Array(N); // 1 = background
    const st = new Int32Array(N); let sp = 0;
    const seed = (i) => { if (!mask[i] && isBg(i)) { mask[i] = 1; st[sp++] = i; } };
    for (let x = 0; x < w; x++) { seed(x); seed((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { seed(y * w); seed(y * w + w - 1); }
    while (sp) {
      const i = st[--sp], x = i % w;
      if (x > 0) seed(i - 1); if (x < w - 1) seed(i + 1);
      if (i >= w) seed(i - w); if (i < N - w) seed(i + w);
    }
    // keep only meaningful foreground islands (removes speckles)
    const lab = new Int32Array(N); const sizes = [0]; let L = 0;
    for (let s0 = 0; s0 < N; s0++) {
      if (mask[s0] || lab[s0]) continue;
      L++; let n = 0; sp = 0; st[sp++] = s0; lab[s0] = L;
      while (sp) {
        const i = st[--sp], x = i % w; n++;
        const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, i >= w ? i - w : -1, i < N - w ? i + w : -1];
        for (const j of nb) if (j >= 0 && !mask[j] && !lab[j]) { lab[j] = L; st[sp++] = j; }
      }
      sizes.push(n);
    }
    const biggest = Math.max(0, ...sizes), minKeep = Math.max(40, biggest * 0.015);
    for (let i = 0; i < N; i++) {
      if (mask[i] || sizes[lab[i]] < minKeep) { p[i * 4 + 3] = 0; mask[i] = 1; }
    }
    // soft edge: foreground pixels touching background fade by colour distance
    for (let i = 0; i < N; i++) {
      if (mask[i]) continue;
      const x = i % w;
      const edge = (x > 0 && mask[i - 1]) || (x < w - 1 && mask[i + 1]) || (i >= w && mask[i - w]) || (i < N - w && mask[i + w]);
      if (edge) p[i * 4 + 3] = Math.round(p[i * 4 + 3] * (0.35 + 0.65 * clamp((dist(i) - tol) / tol, 0, 1)));
    }
    cx.putImageData(im, 0, 0);
    return biggest / N;
  }

  /** AI person segmentation (MediaPipe, loaded on demand from CDN) */
  let segP = null;
  function getSegmenter() {
    if (!segP) {
      segP = (async () => {
        const V = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
        const vision = await import(V + '/vision_bundle.mjs');
        const files = await vision.FilesetResolver.forVisionTasks(V + '/wasm');
        return vision.ImageSegmenter.createFromOptions(files, {
          baseOptions: { modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/latest/selfie_multiclass_256x256.tflite' },
          runningMode: 'IMAGE', outputCategoryMask: false, outputConfidenceMasks: true
        });
      })();
      segP.catch(() => { segP = null; });
    }
    return segP;
  }
  async function aiCut(cv) {
    const seg = await withTimeout(getSegmenter(), 30000, 'מודל ה-AI לא נטען');
    const res = seg.segment(cv);
    try {
      const m = res.confidenceMasks && res.confidenceMasks[0];
      if (!m) throw new Error('no mask');
      const bgc = m.getAsFloat32Array(), mw = m.width, mh = m.height;
      const w = cv.width, h = cv.height, cx = ctx2d(cv), im = cx.getImageData(0, 0, w, h), p = im.data;
      let fg = 0;
      for (let y = 0; y < h; y++) {
        const my = Math.min(mh - 1, Math.floor(y * mh / h));
        for (let x = 0; x < w; x++) {
          const a = 1 - bgc[my * mw + Math.min(mw - 1, Math.floor(x * mw / w))];
          const al = clamp((a - 0.25) / 0.5, 0, 1); // sharpen the soft mask
          const i = (y * w + x) * 4; p[i + 3] = Math.round(p[i + 3] * al); if (al > 0.5) fg++;
        }
      }
      if (fg / (w * h) < 0.03) throw new Error('לא זוהה אדם בתמונה');
      cx.putImageData(im, 0, 0);
    } finally { if (res.close) res.close(); }
  }

  function trim(cv) {
    const w = cv.width, h = cv.height, d = ctx2d(cv).getImageData(0, 0, w, h).data;
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 12) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return cv;
    const c = canvas(x1 - x0 + 1, y1 - y0 + 1); c.getContext('2d').drawImage(cv, -x0, -y0); return c;
  }

  let fontReady = null;
  function loadFont() {
    if (!fontReady) fontReady = (document.fonts && document.fonts.load ? withTimeout(document.fonts.load('900 64px Heebo'), 2500).catch(() => { }) : Promise.resolve());
    return fontReady;
  }

  /** The renderer: source image + params → 512×512 WebP (≤100KB) */
  async function renderSticker(src, params) {
    const p = Object.assign({}, DEF, params);
    await loadFont();
    const img = await loadImg(src);
    let layer, note = '';
    if (p.shape === 'circle' || p.shape === 'rounded') layer = shapeCrop(img, 640, p.shape);
    else {
      layer = fitCanvas(img, 640);
      if (p.shape === 'cut') {
        if (p.cut === 'ai') {
          try { await aiCut(layer); } catch (e) { layer = fitCanvas(img, 640); colorCut(layer, p.tol); note = 'ai-fallback'; }
        } else colorCut(layer, p.tol);
      }
      layer = trim(layer);
    }
    const ol = Number(p.outline) || 0;
    const pad = ol + (p.shadow ? 8 : 0) + 6;
    const capH = p.caption ? Math.round(92 * p.capSize) : 0;
    const areaW = 512 - 2 * pad, areaH = 512 - 2 * pad - capH * 0.82;
    const s = Math.min(areaW / layer.width, areaH / layer.height);
    const w = layer.width * s, h = layer.height * s;
    const x = (512 - w) / 2;
    const y = p.caption ? (p.capPos === 'top' ? 512 - pad - h : pad) : (512 - h) / 2;
    const t = canvas(512); t.getContext('2d').drawImage(layer, x, y, w, h);

    const out = canvas(512), c = out.getContext('2d');
    let base = t;
    if (ol > 0) {
      const sil = canvas(512), sc = sil.getContext('2d');
      sc.drawImage(t, 0, 0); sc.globalCompositeOperation = 'source-in'; sc.fillStyle = '#fff'; sc.fillRect(0, 0, 512, 512);
      const dil = canvas(512), dc = dil.getContext('2d');
      for (const r of [ol, ol * 0.66, ol * 0.33]) for (let a = 0; a < 360; a += 6) { const rad = a * Math.PI / 180; dc.drawImage(sil, Math.cos(rad) * r, Math.sin(rad) * r); }
      base = smoothSil(dil, Math.max(3, ol * 1.1));
    }
    if (p.shadow) { c.save(); c.shadowColor = 'rgba(0,0,0,.38)'; c.shadowBlur = 14; c.shadowOffsetY = 5; c.drawImage(base, 0, 0); c.restore(); }
    else if (base !== t) c.drawImage(base, 0, 0);
    c.drawImage(t, 0, 0);
    if (p.caption) {
      const cy = p.capPos === 'top' ? pad + capH / 2 : 512 - pad - capH / 2;
      drawCaption(c, p.caption, cy, Math.round(64 * p.capSize), p.capColor);
    }
    const enc = encode(out);
    return { out: enc, bytes: bytesOf(enc), note };
  }

  // v2.14: round off a ragged silhouette (blur + re-threshold) so the white border is clean, not torn
  function smoothSil(src, r) {
    try {
      const o = canvas(512), oc = ctx2d(o);
      oc.filter = 'blur(' + r + 'px)'; oc.drawImage(src, 0, 0); oc.filter = 'none';
      const im = oc.getImageData(0, 0, 512, 512), d = im.data;
      for (let i = 0; i < d.length; i += 4) { const a = clamp((d[i + 3] - 95) * 4, 0, 255); d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = a; }
      oc.putImageData(im, 0, 0);
      return o;
    } catch (e) { return src; }
  }

  function drawCaption(c, text, y, size, color) {
    const g3 = COLORS[color] || COLORS.gold;
    c.save(); c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'rtl';
    let f = size;
    const font = (n) => `900 ${n}px Heebo, "Arial Black", system-ui, sans-serif`;
    c.font = font(f);
    while (c.measureText(text).width > 472 && f > 20) { f -= 2; c.font = font(f); }
    c.lineJoin = 'round'; c.miterLimit = 2;
    c.lineWidth = Math.max(8, f * 0.26); c.strokeStyle = '#111'; c.strokeText(text, 256, y);
    c.lineWidth = Math.max(4, f * 0.1); c.strokeStyle = '#fff'; c.strokeText(text, 256, y);
    const g = c.createLinearGradient(0, y - f / 2, 0, y + f / 2);
    g.addColorStop(0, g3[0]); g.addColorStop(0.45, g3[1]); g.addColorStop(1, g3[2]);
    c.fillStyle = g; c.fillText(text, 256, y); c.restore();
  }

  async function textCreation(text, emoji) {
    await loadFont();
    const out = canvas(512), c = out.getContext('2d');
    c.font = '230px system-ui, "Noto Color Emoji", "Apple Color Emoji", sans-serif';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.save(); c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 14; c.shadowOffsetY = 6;
    c.fillText(Array.from(emoji || '😀')[0] || '😀', 256, text ? 200 : 256); c.restore();
    if (text) drawCaption(c, text, 420, 84, 'gold');
    const enc = encode(out);
    const src = out.toDataURL('image/png');
    return { id: uid('s_'), src, p: Object.assign({}, DEF, { shape: 'none', outline: 0, shadow: false, caption: '' }), out: enc, bytes: bytesOf(enc), emoji: emoji || '😀', textOnly: true };
  }

  function encode(cv) {
    let q = 0.92, url;
    do {
      url = cv.toDataURL('image/webp', q);
      if (!url.startsWith('data:image/webp')) throw new Error('המכשיר לא תומך ב-WebP');
      q -= 0.07;
    } while (bytesOf(url) > LIMIT && q > 0.15);
    if (bytesOf(url) > LIMIT) { // last resort: downscale detail then upscale back to 512
      const s = canvas(384); s.getContext('2d').drawImage(cv, 0, 0, 384, 384);
      const b = canvas(512); b.getContext('2d').drawImage(s, 0, 0, 512, 512);
      url = b.toDataURL('image/webp', 0.7);
    }
    return url;
  }

  // ================= editor =================
  const ED = { cr: null, p: null, onApply: null, timer: 0, token: 0 };
  Object.entries(COLORS).forEach(([k, g]) => {
    const b = document.createElement('button'); b.dataset.v = k; b.title = k;
    b.style.background = `linear-gradient(135deg,${g[0]},${g[1]},${g[2]})`; $('edColor').appendChild(b);
  });
  function segSet(id, val) { $(id).querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === String(val))); }
  ['edPos', 'edColor', 'edShape', 'edCut', 'edOutline'].forEach((id) => {
    $(id).addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b || !ED.p) return;
      const key = $(id).dataset.key; ED.p[key] = key === 'outline' ? Number(b.dataset.v) : b.dataset.v;
      segSet(id, b.dataset.v); syncEditorUi(); queueRender(); haptic(6);
    });
  });
  $('edCaption').addEventListener('input', () => { ED.p.caption = $('edCaption').value; queueRender(); });
  $('edSize').addEventListener('input', () => { ED.p.capSize = Number($('edSize').value); syncEditorUi(); queueRender(); });
  $('edTol').addEventListener('input', () => { ED.p.tol = Number($('edTol').value); syncEditorUi(); queueRender(); });
  $('edShadow').addEventListener('change', () => { ED.p.shadow = $('edShadow').checked; queueRender(); });

  function openEditor(cr, opts) {
    if (cr.textOnly) return toast('מדבקת טקסט – אפשר ליצור חדשה עם כיתוב אחר');
    ED.cr = cr; ED.p = Object.assign({}, DEF, cr.p); ED.onApply = (opts && opts.onApply) || null; ED.inPack = !!(opts && opts.inPack);
    $('edCaption').value = ED.p.caption || ''; $('edSize').value = ED.p.capSize; $('edTol').value = ED.p.tol;
    $('edShadow').checked = !!ED.p.shadow; $('edEmoji').value = cr.emoji || '';
    segSet('edPos', ED.p.capPos); segSet('edColor', ED.p.capColor); segSet('edShape', ED.p.shape); segSet('edCut', ED.p.cut); segSet('edOutline', ED.p.outline);
    $('edImg').src = cr.out; ED.preview = { out: cr.out, bytes: cr.bytes }; setEdInfo(cr.bytes);
    $('edAdd').hidden = ED.inPack || !!S.cur.stickers.find((s) => s.id === cr.id);
    syncEditorUi(); show('editor');
  }
  function syncEditorUi() {
    $('cutBox').hidden = ED.p.shape !== 'cut';
    $('edSizeOut').textContent = Math.round(ED.p.capSize * 100) + '%';
    $('edTolOut').textContent = ED.p.tol;
  }
  function setEdInfo(b) { const el = $('edInfo'); el.textContent = `${kb(b)} ${b <= LIMIT ? '✓' : '⚠️'}`; el.classList.toggle('bad', b > LIMIT); }
  function queueRender() {
    clearTimeout(ED.timer);
    ED.timer = setTimeout(async () => {
      const tok = ++ED.token; document.querySelector('.preview').classList.add('busy');
      try {
        const r = await renderSticker(ED.cr.src, ED.p);
        if (tok !== ED.token) return;
        ED.preview = r; $('edImg').src = r.out; setEdInfo(r.bytes);
        if (r.note === 'ai-fallback') toast('חיתוך AI לא זמין כרגע – השתמשתי בחיתוך צבע');
      } catch (e) { toast('😕 ' + e.message); }
      finally { if (tok === ED.token) document.querySelector('.preview').classList.remove('busy'); }
    }, 160);
  }
  function commitEditor() {
    const cr = ED.cr; cr.p = Object.assign({}, ED.p); cr.out = ED.preview.out; cr.bytes = ED.preview.bytes;
    cr.emoji = cleanEmoji($('edEmoji').value) || cr.emoji || '😀';
    const inPack = S.packs.find((pk) => pk.stickers.some((s) => s.id === cr.id));
    if (inPack) { const s = inPack.stickers.find((x) => x.id === cr.id); Object.assign(s, packEntry(cr)); touch(inPack); renderPack(); }
    if (ED.onApply) ED.onApply();
  }
  $('edApply').onclick = async () => { clearTimeout(ED.timer); await waitRender(); commitEditor(); hide('editor'); toast('✓ נשמר'); };
  $('edAdd').onclick = async () => { clearTimeout(ED.timer); await waitRender(); commitEditor(); if (addToPack(ED.cr)) hide('editor'); };
  async function waitRender() {
    // make sure the latest params are rendered before committing
    const tok = ++ED.token;
    try { const r = await renderSticker(ED.cr.src, ED.p); if (tok === ED.token) ED.preview = r; } catch (e) { }
    document.querySelector('.preview').classList.remove('busy');
  }
  function cleanEmoji(s) { return (String(s || '').match(/\p{Extended_Pictographic}(️|‍\p{Extended_Pictographic})*/gu) || []).slice(0, 3).join(''); }

  // ================= pack =================
  const packEntry = (cr) => ({ id: cr.id, src: cr.src, p: cr.p, out: cr.out, bytes: cr.bytes, emoji: cr.emoji || '😀', textOnly: !!cr.textOnly });
  function addToPack(cr) {
    const pk = S.cur;
    if (pk.stickers.some((s) => s.id === cr.id)) { toast('כבר בחבילה'); return true; }
    if (pk.stickers.length >= MAX) { bot(`החבילה "${pk.name}" מלאה (30). פתח חבילה חדשה ב-📦.`); return false; }
    if (cr.bytes > LIMIT) { toast('⚠️ המדבקה גדולה מדי לווצאפ – נסה עריכה'); return false; }
    pk.stickers.push(packEntry(cr)); touch(pk); renderPack(); haptic(30);
    const pill = $('btnPack'); pill.classList.remove('bump'); void pill.offsetWidth; pill.classList.add('bump');
    if (pk.stickers.length === MIN) bot('🎉 יש 3 מדבקות! לחץ על 📦 למעלה כדי להוסיף לווצאפ.');
    else toast(`נוסף לחבילה (${pk.stickers.length}/${MAX})`);
    return true;
  }

  function renderPack() {
    const pk = S.cur; if (!pk) return;
    $('count').textContent = pk.stickers.length;
    const sel = $('packSel'); sel.innerHTML = '';
    S.packs.forEach((p) => { const o = document.createElement('option'); o.value = p.id; o.textContent = `${p.name} (${p.stickers.length})`; if (p === pk) o.selected = true; sel.appendChild(o); });
    if (document.activeElement !== $('packName')) $('packName').value = pk.name;
    const g = $('grid'); g.innerHTML = '';
    if (!pk.stickers.length) g.innerHTML = '<div class="empty">החבילה ריקה. צור מדבקה ולחץ ➕ לחבילה</div>';
    const trayId = pk.trayId && pk.stickers.some((s) => s.id === pk.trayId) ? pk.trayId : (pk.stickers[0] && pk.stickers[0].id);
    pk.stickers.forEach((s, i) => {
      const d = document.createElement('div'); d.className = 'cell' + (s.id === trayId ? ' tray' : '');
      d.innerHTML = `<img src="${s.out}" alt=""><span class="em">${esc(Array.from(s.emoji || '')[0] || '')}</span>`;
      d.onclick = () => openMenu(i); g.appendChild(d);
    });
    // status / validation
    const st = [];
    const n = pk.stickers.length, big = pk.stickers.filter((s) => s.bytes > LIMIT).length;
    st.push(n >= MIN ? `<span>✓ ${n}/${MAX} מדבקות</span>` : `<span class="warn">${n}/${MAX} · חסרות ${MIN - n}</span>`);
    st.push(big ? `<span class="warn">${big} גדולות מ-100KB</span>` : '<span>✓ 512×512 · עד 100KB</span>');
    if (pk.sentVersion) st.push(pk.dirty ? '<span class="info">יש שינויים – לחץ עדכן</span>' : '<span class="info" id="waState">נשלחה לווצאפ</span>');
    $('packStatus').innerHTML = st.join('');
    $('btnAdd').textContent = pk.sentVersion ? (pk.dirty ? '🔄 עדכן בווצאפ' : '📲 שלח שוב לווצאפ') : '📲 הוסף לווצאפ';
    $('btnAdd').disabled = n < MIN || !!big;
    localStorage.setItem('da_sticker_cur', pk.id);
  }

  $('btnPack').onclick = () => {
    renderPack(); show('sheet');
    const b = bridge();
    if (b && b.isPackAdded && S.cur.sentVersion) {
      try { const r = b.isPackAdded(S.cur.id); const el = $('waState'); if (el && r === '1') el.textContent = '✓ מותקנת בווצאפ'; } catch (e) { }
    }
  };
  $('packSel').onchange = () => { S.cur = S.packs.find((p) => p.id === $('packSel').value) || S.cur; renderPack(); };
  $('packName').addEventListener('change', () => { S.cur.name = $('packName').value.trim().slice(0, 60) || 'DA Stickers'; touch(S.cur); renderPack(); });
  $('btnNewPack').onclick = () => {
    const p = newPack('חבילה ' + (S.packs.length + 1)); S.packs.push(p); S.cur = p; persist(p); renderPack();
    $('packName').focus(); $('packName').select(); toast('נוצרה חבילה חדשה');
  };
  $('btnDelPack').onclick = async () => {
    const pk = S.cur;
    if (!confirm(`למחוק את החבילה "${pk.name}" עם ${pk.stickers.length} מדבקות?`)) return;
    S.packs = S.packs.filter((p) => p !== pk);
    try { await DB.del(pk.id); } catch (e) { }
    try { const b = bridge(); if (b && b.deletePack) b.deletePack(pk.id); } catch (e) { }
    if (!S.packs.length) { const p = newPack(); S.packs.push(p); persist(p); }
    S.cur = S.packs[S.packs.length - 1]; renderPack(); toast('החבילה נמחקה');
  };

  // sticker menu
  let menuIdx = -1;
  function openMenu(i) {
    menuIdx = i; const s = S.cur.stickers[i];
    $('menuImg').src = s.out; $('menuInfo').textContent = `${i + 1}/${S.cur.stickers.length} · ${kb(s.bytes)} · ${s.emoji}`;
    show('menu');
  }
  $('menu').addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const pk = S.cur, arr = pk.stickers, s = arr[menuIdx]; if (!s) return;
    const act = b.dataset.act;
    if (act === 'edit') { hide('menu'); hide('sheet'); openEditor(s, { inPack: true, onApply: () => { renderPack(); show('sheet'); } }); return; }
    if (act === 'emoji') { const v = cleanEmoji(prompt('אימוג\'י למדבקה (עד 3):', s.emoji)); if (v) { s.emoji = v; touch(pk); } }
    if (act === 'tray') { pk.trayId = s.id; touch(pk); toast('⭐ נקבע כאייקון'); }
    if (act === 'right' && menuIdx > 0) { arr.splice(menuIdx - 1, 0, arr.splice(menuIdx, 1)[0]); touch(pk); }
    if (act === 'left' && menuIdx < arr.length - 1) { arr.splice(menuIdx + 1, 0, arr.splice(menuIdx, 1)[0]); touch(pk); }
    if (act === 'del') { arr.splice(menuIdx, 1); if (pk.trayId === s.id) pk.trayId = null; touch(pk); }
    hide('menu'); renderPack();
  });

  async function trayIcon(pk) {
    const s = pk.stickers.find((x) => x.id === pk.trayId) || pk.stickers[0];
    const img = await loadImg(s.out);
    const c = canvas(96); c.getContext('2d').drawImage(img, 0, 0, 96, 96);
    let url = c.toDataURL('image/png');
    if (bytesOf(url) > TRAY_LIMIT) { const d = canvas(96); const x = d.getContext('2d'); x.drawImage(img, 4, 4, 88, 88); url = d.toDataURL('image/png'); }
    return url;
  }

  $('btnAdd').onclick = async () => {
    const pk = S.cur, b = bridge();
    if (pk.stickers.length < MIN) return toast(`צריך לפחות ${MIN} מדבקות (יש ${pk.stickers.length})`);
    if (!b) return bot('📱 ההוספה לווצאפ עובדת מתוך אפליקציית DA.ai באנדרואיד. כאן בדפדפן אפשר לשמור את המדבקות (💾).');
    if (pk.dirty && pk.sentVersion) pk.version = (pk.version || 1) + 1;
    const json = JSON.stringify({
      identifier: pk.id, name: pk.name, publisher: pk.publisher || 'DA.ai', version: String(pk.version || 1),
      tray: await trayIcon(pk),
      stickers: pk.stickers.map((s) => ({ data: s.out, emoji: s.emoji || '😀', text: (s.p && s.p.caption) || '' }))
    });
    pk.pendingVersion = pk.version;
    const r = b.addPack(json);
    hide('sheet');
    bot(r === 'ok' ? '📲 פותח את ווצאפ… אשר שם "הוסף".' : r);
  };
  window.onStickerResult = (m, ok) => {
    bot(m); haptic(ok ? 60 : 20);
    if (ok) { const pk = S.packs.find((p) => p.pendingVersion) || S.cur; pk.sentVersion = pk.pendingVersion || pk.version; pk.dirty = false; delete pk.pendingVersion; persist(pk); renderPack(); }
  };

  function saveOne(cr) {
    const b = bridge();
    if (b && b.saveToGallery) return toast(b.saveToGallery(JSON.stringify({ stickers: [{ data: cr.out }] })));
    const a = document.createElement('a'); a.href = cr.out; a.download = `DA_sticker_${Date.now()}.webp`; a.click();
  }
  $('btnSave').onclick = () => {
    const pk = S.cur; if (!pk.stickers.length) return toast('החבילה ריקה');
    const b = bridge();
    if (b && b.saveToGallery) return bot(b.saveToGallery(JSON.stringify({ stickers: pk.stickers.map((s) => ({ data: s.out })) })));
    pk.stickers.forEach((s, i) => setTimeout(() => { const a = document.createElement('a'); a.href = s.out; a.download = `${pk.name}_${i + 1}.webp`; a.click(); }, i * 250));
  };

  // ================= welcome =================
  function welcome() {
    const d = bubble('a', esc('היי! 👋 ברוך הבא לסטודיו המדבקות של DA.ai\n\n' +
      '✍️ כתוב מה אתה רוצה – למשל: חתול עם משקפי שמש שאומר "יאללה"\n' +
      '🖼️ או צרף תמונה וכתוב מה לעשות – למשל: תעשה ממני מדבקה עם "בוקר טוב"\n' +
      '×4 = ארבע גרסאות בבת אחת · ✏️ = עריכה מלאה אחרי היצירה') + '<div class="sugs"></div>');
    const ideas = ['אריה עם כתר שאומר "מלך"', 'קפה חמוד שאומר "בוקר טוב"', 'חתול מתבאס שאומר "אוף"', 'עוגת יום הולדת שאומרת "מזל טוב"', 'כלב עם משקפי שמש "יאללה"'];
    ideas.forEach((t) => { const b = document.createElement('button'); b.textContent = t; b.onclick = () => { msg.value = t; msg.dispatchEvent(new Event('input')); send(); }; d.querySelector('.sugs').appendChild(b); });
  }

  // ================= boot =================
  $('ver').textContent = VERSION;
  loadCfg();
  document.querySelectorAll('#styles button').forEach((b, i) => b.classList.toggle('on', STYLES[i] === S.style));
  updateNet();
  welcome();
  loadPacks().then(() => {
    renderPack();
    if (S.cur.stickers.length) bot(`📦 החבילה "${S.cur.name}" נטענה עם ${S.cur.stickers.length} מדבקות.`);
  });

  // test hook (used by automated checks only)
  window.__DA_STICKERS__ = { renderSticker, colorCut, parse, version: VERSION, state: S };
})();
